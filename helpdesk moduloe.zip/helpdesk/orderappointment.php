<?php
include 'connect.php';
session_start();
if (!isset($_SESSION["employeeid"])) 
{
    header("Location: login.php");
exit();
}


?>


<?php
include 'connect.php';
$edit_state = false;
if (isset($_GET['edit'])) {
    $appointment_id = $_GET['edit'];
    $edit_state = true;

    $res = mysqli_query($conn, "SELECT * FROM order_appointment WHERE appointment_id =$appointment_id ");
    $data = mysqli_fetch_array($res);
    $ord_id  = $data['ord_id'];
    $appointment_date = $data['appointment_date'];
    $appointment_detail = $data['appointment_detail'];
    $appointment_doc = $data['appointment_doc'];
    $appointment_time = $data['appointment_time'];
    $appointment_address = $data['appointment_address'];
    $appointment_doc = $data['appointment_doc'];
    $remark = $data['remark'];
    $app_status = $data['app_status'];
}
?>


<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

<head>
    <title>Admindek | Admin Template</title>
    <!-- HTML5 Shim and Respond.js IE10 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 10]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    <!-- Meta -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="description"
        content="Admindek Bootstrap admin template made using Bootstrap 4 and it has huge amount of ready made feature, UI components, pages which completely fulfills any dashboard needs." />
    <meta name="keywords"
        content="flat ui, admin Admin , Responsive, Landing, Bootstrap, App, Template, mobileno, iOS, Android, apple, creative app">
    <meta name="author" content="colorlib" />
    <link rel="stylesheet" href="icon.css">
    <link rel="icon" href="https://colorlib.com//polygon/admindek/files/assets/images/favicon.ico" type="image/x-icon">
    <!-- Google font-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Quicksand:500,700" rel="stylesheet">
    <!-- Required Framework -->
    <link rel="stylesheet" type="text/css" href="bower_components/bootstrap/css/bootstrap.min.css">
    <!-- waves.css -->
    <link rel="stylesheet" href="assets/pages/waves/css/waves.min.css" type="text/css" media="all">
    <!-- feather icon -->
    <link rel="stylesheet" type="text/css" href="assets/icon/feather/css/feather.css">
    <!-- font-awesome-n -->
    <link rel="stylesheet" type="text/css" href="assets/css/font-awesome-n.min.css">
    <!-- Chartlist chart CSS -->
    <link rel="stylesheet" href="bower_components/chartist/css/chartist.css" type="text/css" media="all">
    <!-- Style.css -->
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="assets/css/widget.css">
    <!-- themify-icons line icon -->
    <link rel="stylesheet" type="text/css" href="assets/icon/themify-icons/themify-icons.css">
    <!-- ico font -->
    <link rel="stylesheet" type="text/css" href="assets/icon/icofont/css/icofont.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" type="text/css" href="assets/icon/font-awesome/css/font-awesome.min.css">
    <!-- Date-time picker CSS -->
    <link rel="stylesheet" type="text/css" href="assets/pages/advance-elements/css/bootstrap-datetimepicker.css">
    <!-- Date-range picker CSS -->
    <link rel="stylesheet" type="text/css" href="bower_components/bootstrap-daterangepicker/css/daterangepicker.css" />
    <!-- Date-Dropper CSS -->
    <link rel="stylesheet" type="text/css" href="bower_components/datedropper/css/datedropper.min.css" />
    <!-- Color Picker CSS -->
    <link rel="stylesheet" type="text/css" href="bower_components/spectrum/css/spectrum.css" />
    <!-- Mini-color CSS -->
    <link rel="stylesheet" type="text/css" href="bower_components/jquery-minicolors/css/jquery.minicolors.css" />
    <!-- Select 2 CSS -->
    <link rel="stylesheet" href="bower_components/select2/css/select2.min.css" />
    <!-- Multi Select CSS -->
    <link rel="stylesheet" type="text/css"
        href="bower_components/bootstrap-multiselect/css/bootstrap-multiselect.css" />
    <link rel="stylesheet" type="text/css" href="bower_components/multiselect/css/multi-select.css" />
    <!-- Forms-wizard CSS -->
    <link rel="stylesheet" type="text/css" href="bower_components/jquery.steps/css/jquery.steps.css">
    <!-- Data Table Css -->
    <link rel="stylesheet" type="text/css" href="bower_components/datatables.net-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" type="text/css" href="assets/pages/data-table/css/buttons.dataTables.min.css">
    <link rel="stylesheet" type="text/css"
        href="bower_components/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css">
    <link rel="icon" href="https://colorlib.com//polygon/admindek/files/assets/images/favicon.ico" type="image/x-icon">
    <!-- Switch component css -->
    <link rel="stylesheet" type="text/css" href="bower_components/switchery/css/switchery.min.css">
    <!-- Tags css -->
    <link rel="stylesheet" type="text/css" href="bower_components/bootstrap-tagsinput/css/bootstrap-tagsinput.css" />


    <link rel="icon" href="https://colorlib.com//polygon/admindek/files/assets/images/favicon.ico" type="image/x-icon">
    <!-- Bootstrap Modalsgle font-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Quicksand:500,700" rel="stylesheet">
    <!-- Required Fremwork -->
    <link rel="stylesheet" type="text/css" href="bower_components/bootstrap/css/bootstrap.min.css">
    <!-- waves.css -->
    <link rel="stylesheet" href="assets/pages/waves/css/waves.min.css" type="text/css" media="all">
    <!-- feather icon -->
    <link rel="stylesheet" type="text/css" href="assets/icon/feather/css/feather.css">
    <!-- sweet alert framework -->
    <link rel="stylesheet" type="text/css" href="bower_components/sweetalert/css/sweetalert.css">
    <!-- themify-icons line icon -->
    <link rel="stylesheet" type="text/css" href="assets/icon/themify-icons/themify-icons.css">
    <!-- ico font -->
    <link rel="stylesheet" type="text/css" href="assets/icon/icofont/css/icofont.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" type="text/css" href="assets/icon/font-awesome/css/font-awesome.min.css">
    <!-- animation nifty modal window effects css -->
    <link rel="stylesheet" type="text/css" href="assets/css/component.css">
    <!-- Style.css -->
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="assets/css/pages.css">
 


</head>

<body>
    <!-- [ Pre-loader ] start -->
    <div class="loader-bg">
        <div class="loader-bar"></div>
    </div>
    <!-- [ Pre-loader ] end -->
    <div id="pcoded" class="pcoded">
        <div class="pcoded-overlay-box"></div>
        <div class="pcoded-container navbar-wrapper">
            <!-- [ Header ] start -->
            <nav class="navbar header-navbar pcoded-header">
                <div class="navbar-wrapper">
                    <div class="navbar-logo">
                        <a href="index.html">
                            <img class="img-fluid" src="assets/images/logo.png" alt="Theme-Logo" />
                        </a>
                        <a class="mobile-menu" id="mobile-collapse" href="#!">
                            <i class="feather icon-menu icon-toggle-right"></i>
                        </a>
                        <a class="mobile-options waves-effect waves-light">
                            <i class="feather icon-more-horizontal"></i>
                        </a>
                    </div>
                    <div class="navbar-container container-fluid">
                        <ul class="nav-left">
                            <li class="header-search">
                                <div class="main-search morphsearch-search">
                                    <div class="input-group">
                                        <span class="input-group-prepend search-close">
                                            <i class="feather icon-x input-group-text"></i>
                                        </span>
                                        <input type="text" class="form-control" placeholder="Enter Keyword">
                                        <span class="input-group-append search-btn">
                                            <i class="feather icon-search input-group-text"></i>
                                        </span>
                                    </div>
                                </div>
                            </li>
                            
                            <li>
                                <a href="#!" onclick="javascript:toggleFullScreen()" class="waves-effect waves-light">
                                    <i class="full-screen feather icon-maximize"></i>
                                </a>
                            </li>
                        </ul>
                       
                        <ul class="nav-right">
                            
                        <li class="header">
    <div class="dropdown-primary dropdown">
        <div class="dropdown-toggle" data-toggle="dropdown">
            <i class="fa fa-calendar-o"> <span ><?php echo $_SESSION['year_name'];?></span></i>
        </div>
    </div>
</li>
<li class="header">
    <div class="dropdown-primary dropdown">
        <div class="dropdown-toggle" data-toggle="dropdown">
            <i class="fa fa-building-o"> <span ><?php echo $_SESSION['comp_name'];?></span></i>
        </div>
    </div>
</li>

                            <li class="header-notification">
                                <div class="dropdown-primary dropdown">
                                    <div class="dropdown-toggle" data-toggle="dropdown">
                                        <i class="feather icon-bell"></i>
                                        <span class="badge bg-c-red">5</span>
                                    </div>
                                    <ul class="show-notification notification-view dropdown-menu" data-dropdown-in="fadeIn" data-dropdown-out="fadeOut">
                                        <li>
                                            <h6>Notifications</h6>
                                            <label class="label label-danger">New</label>
                                        </li>
                                        <li>
                                            <div class="media">
                                                <img class="img-radius" src="assets/images/avatar-4.jpg" alt="Generic placeholder image">
                                                <div class="media-body">
                                                    <h5 class="notification-user">John Doe</h5>
                                                    <p class="notification-msg">Lorem ipsum dolor sit amet, consectetuer elit.</p>
                                                    <span class="notification-time">30 minutes ago</span>
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="media">
                                                <img class="img-radius" src="assets/images/avatar-3.jpg" alt="Generic placeholder image">
                                                <div class="media-body">
                                                    <h5 class="notification-user">Joseph William</h5>
                                                    <p class="notification-msg">Lorem ipsum dolor sit amet, consectetuer elit.</p>
                                                    <span class="notification-time">30 minutes ago</span>
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="media">
                                                <img class="img-radius" src="assets/images/avatar-4.jpg" alt="Generic placeholder image">
                                                <div class="media-body">
                                                    <h5 class="notification-user">Sara Soudein</h5>
                                                    <p class="notification-msg">Lorem ipsum dolor sit amet, consectetuer elit.</p>
                                                    <span class="notification-time">30 minutes ago</span>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="header-notification">
                                <div class="dropdown-primary dropdown">
                                    <div class="displayChatbox dropdown-toggle" data-toggle="dropdown">
                                        <i class="feather icon-message-square"></i>
                                        <span class="badge bg-c-green">3</span>
                                    </div>
                                </div>
                            </li>
                            <li class="user-profile header-notification">

                                <div class="dropdown-primary dropdown">
                                    <div class="dropdown-toggle" data-toggle="dropdown">
                                        <img src="assets/images/avatar-4.jpg" class="img-radius"
                                            alt="User-Profile-Image">
                                        <span><?php echo $_SESSION['employeename']; ?></span>
                                        <i class="feather icon-chevron-down"></i>
                                    </div>
                                    <ul class="show-notification profile-notification dropdown-menu"
                                        data-dropdown-in="fadeIn" data-dropdown-out="fadeOut">
                                        <!-- <li>
                                            <a href="#!">
                                                <i class="feather icon-settings"></i> Settings

                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <i class="feather icon-user"></i> Profile

                                            </a>
                                        </li>
                                        <li>
                                            <a href="email-inbox.html">
                                                <i class="feather icon-mail"></i> My Messages

                                            </a>
                                        </li>
                                        <li>
                                            <a href="auth-lock-screen.html">
                                                <i class="feather icon-lock"></i> Lock Screen

                                            </a>
                                        </li> -->
                                        <li>
                                            <span id="logout-link">
                                                <i class="feather icon-log-out"></i> Logout
                                            </span>
                                            <script>       
                                                var logoutLink = document.getElementById('logout-link');
                                                logoutLink.addEventListener('click', function(event) {       
                                                    event.preventDefault();        
                                                    var confirmLogout = confirm("Are you sure you want to logout?");
                                                    if (confirmLogout) {
                                                        window.location.href = "logout.php";
                                                    } else {
                                                        // Do nothing, user chose not to logout
                                                    }
                                                });
                                            </script>
                                        </li>


                                    </ul>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <!-- [ chat user list ] start -->
          
            <!-- [ chat user list ] end -->

  
            <!-- [ chat message ] end -->


            <div class="pcoded-main-container">
                <div class="pcoded-wrapper">
                    <!-- [ navigation menu ] start -->
                    <nav class="pcoded-navbar">

                        <div class="nav-list">
                            <div class="pcoded-inner-navbar main-menu">
                                <div class="pcoded-navigation-label"></div>
                                <ul class="pcoded-item pcoded-left-item">
                                    <li class="pcoded-hasmenu">
                                        <a href="javascript:void(0)" class="waves-effect waves-dark">
                                            <span class="pcoded-micon"><i class="feather icon-home"></i></span>
                                            <span class="pcoded-mtext">Dashboard</span>
                                        </a>
                                        <ul class="pcoded-submenu">
                                            <li class="">
                                                <a href="orderappointment.php" class="waves-effect waves-dark">
                                                    <span class="pcoded-mtext">Appointmant Deatils</span>
                                                </a>
                                            </li>
                                         

                                        </ul>
                                    </li>

                                    </li>
                                </ul>

                            </div>
                        </div>
                    </nav>
                    <!-- [ navigation menu ] end -->
                    <div class="pcoded-content">
                        <!-- [ breadcrumb ] start -->
                        <div class="page-header card">
                            <div class="row align-items-end">
                                <div class="col-lg-8">
                                    <div class="page-header-title">
                                        <i class="feather icon-clipboard bg-c-blue"></i>
                                        <div class="d-inline">
                                            <h5>Appointmant Details</h5>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <!-- [ breadcrumb ] end -->



                        <div class="pcoded-inner-content">
                            <div class="main-body">
                                <div class="page-wrapper">
                                    <!-- Page body start -->
                                    <div class="page-body">
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <!-- Form wizard with validation card start -->
                                                <div class="card">
                                                    <div class="card-header">
                                                        <h5>Appointmant Details</h5>

                                                    </div>
                                                    <div class="card-block">
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div id="wizard">


                                                                

                                                                <form method="post" action="orderappointment.php" enctype="multipart/form-data">
                                                                        <input type="hidden" name="appointment_id"
                                                                            value="<?php echo $appointment_id; ?>">

                                                                        <div class="card-block">
                                                                        <div class="form-group row ">
                                                                                <label class="col-sm-2 col-form-label">Order Id</label>
                                                                                <div class="col-sm-10 ">
                                                                                <select name="ord_id" class="form-control form-control-primary"  id="ord_id" required>
                                                                                    <option value="" selected disabled>Select Order ID</option>
                                                                                    <option value="<?php if(isset($data['ord_id'])){echo  $data['ord_id']; ?>" <?php echo 'selected' ;}?>><?php if(isset($data['ord_id'])){echo  $data['ord_id']; }?></option>

                                                                                        <?php 
                                                                                            $query ="SELECT ord_id FROM ord_inquiry";
                                                                                            $result = $conn->query($query);
                                                                                            if($result->num_rows> 0)
                                                                                            {
                                                                                                while($optionData=$result->fetch_assoc())
                                                                                                {
                                                                                                    $option =$optionData['ord_id'];
                                                                                                    $ord_id =$optionData['ord_id'];
                                                                                                    ?>
                                                                                                        <option value="<?php echo $ord_id; ?>" > <?php echo $option; ?> </option>
                                                                                                    <?php
                                                                                                }
                                                                                            }
                                                                                        ?>
                                                                                    </select> 
                                                                            </div>
                                                                                </div>
                                                                            
                                                                            <div class="form-group row">
                                                                                <label class="col-sm-2 col-form-label">Appointmant
                                                                                    date</label>
                                                                                <div class="col-sm-10">
                                                                                    <input type="date"
                                                                                        name="appointment_date" required
                                                                                        placeholder="Priority Name"
                                                                                        value="<?php if (isset($data['appointment_date'])) {
                                                                                            echo $data['appointment_date'];
                                                                                        } ?>" class="form-control">
                                                                                </div>
                                                                            </div>
                                                                            <div class="form-group row">
                                                                                <label
                                                                                    class="col-sm-2 col-form-label">Appointmant
                                                                                    Deatils</label>
                                                                                <div class="col-sm-10">
                                                                                    <textarea name="appointment_detail"
                                                                                        class="form-control" Required
                                                                                        placeholder="Appointment Deatils" 
                                                                                        id="inputAddress" rows="3"><?php if (isset($data['appointment_detail'])) {
                                                                                            echo $data['appointment_detail'];
                                                                                        } ?></textarea>
                                                                                </div>
                                                                            </div>
                                                                            <div class="form-group row">
                                                                                <label
                                                                                    class="col-sm-2 col-form-label">Appointmant
                                                                                    Time</label>
                                                                                <div class="col-sm-10">
                                                                                    <input class="form-control" required
                                                                                        name="appointment_time" value="<?php if (isset($data['appointment_time'])) {
                                                                                            echo $data['appointment_time'];
                                                                                        } ?>" type="time" />

                                                                                </div>
                                                                            </div>
                                                                            <div class="form-group row">
                                                                                <label
                                                                                    class="col-sm-2 col-form-label">Address
                                                                                </label>
                                                                                <div class="col-sm-10">
                                                                                    <textarea name="appointment_address"
                                                                                        class="form-control" Required
                                                                                        placeholder="Address"
                                                                                        id="inputAddress" rows="3"><?php if (isset($data['appointment_address'])) {
                                                                                            echo $data['appointment_address'];
                                                                                        } ?></textarea>
                                                                                </div>
                                                                            </div>
                                                                            <div class="form-group row">
                                                                                <label
                                                                                    class="col-sm-2 col-form-label">Appointmant
                                                                                    Upload Documents</label>
                                                                                <div class="col-sm-5">
                                                                               
                                                                                        <input type="file" name="files[]" required multiple
                                                                                             class="form-control form-txt-primary"
                                                                                            value="<?php if (isset($data['appointment_doc'])) {
                                                                                            echo $data['appointment_doc'];
                                                                                            } ?>">

                                                                                </div>
                                                                                <div class="col-sm-5">

                                                                                <!-- <input type="text" name="appointment_doc" multiple value="<?php if (isset($originalappointment_doc))echo $originalappointment_doc; ?>" readonly class="form-control form-txt-primary" placeholder="Display previous file name"><br> -->
                                                                                <textarea name=""
                                                                                        class="form-control" Required readonly
                                                                                        placeholder="appointment_doc"
                                                                                        id="appointment_doc" rows="3"><?php if (isset($data['appointment_doc'])) {
                                                                                            echo $data['appointment_doc'];
                                                                                        } ?></textarea>
                                                                            </div>
                                                                            </div>
                                                                            <div class="form-group row">
                                                                                <label
                                                                                    class="col-sm-2 col-form-label">Remark
                                                                                </label>
                                                                                <div class="col-sm-10">
                                                                                    <textarea name="remark"
                                                                                        class="form-control" Required
                                                                                        placeholder="Remark"
                                                                                        id="inputAddress" rows="3"><?php if (isset($data['remark'])) {
                                                                                            echo $data['remark'];
                                                                                        } ?></textarea>
                                                                                </div>
                                                                            </div>
                                                                            <div class="form-group row">
                                                                                <label
                                                                                    class="col-sm-2 col-form-label">Status
                                                                                </label>
                                                                                <div class="col-sm-10">
                                                                                <div class="form-radio m-b-30">
                                  
                                                                                <div class="radio radiofill radio-default radio-inline">
                                                                                <label>
                                                                                <input type="radio" name="app_status" required value="Pending" <?php if(isset($data['app_status'])){ if($data['app_status']=="Pending"){ ?> checked <?php }} ?> >
                                                                                    <i class="helper"></i>Pending
                                                                                </label>
                                                                                </div>
                                                                                <div class="radio radiofill radio-danger radio-inline">
                                                                                <label>
                                                                                <input type="radio" name="app_status" required value="Cancel" <?php if(isset($data['app_status'])){ if($data['app_status']=="Cancel"){ ?> checked <?php }} ?> >
                                                                                    <i class="helper"></i>Cancel
                                                                                </label>
                                                                                </div>
                                                                                <div class="radio radiofill radio-info radio-inline">
                                                                                <label>
                                                                                <input type="radio" name="app_status" required value="Successful" <?php if(isset($data['app_status'])){ if($data['app_status']=="Successful"){ ?> checked <?php }} ?> >
                                                                                    <i class="helper"></i>Successful
                                                                                </label>
                                                                                </div>
                                                                                <div class="radio radiofill radio-primary radio-inline">
                                                                                <label>
                                                                                <input type="radio" name="app_status" required value="Active" <?php if(isset($data['app_status'])){ if($data['app_status']=="Active"){ ?> checked <?php }} ?> >
                                                                                    <i class="helper"></i>Active
                                                                                </label>
                                                                                </div>
                                                                                <div class="radio radiofill radio-warning radio-inline">
                                                                                <label>
                                                                                <input type="radio" name="app_status"required value="Inactive" <?php if(isset($data['app_status'])){ if($data['app_status']=="Inactive"){ ?> checked <?php }} ?> >
                                                                                    <i class="helper"></i>Inactive
                                                                                </label>
                                                                                </div>
                                                                                
                                                                                                            
                                                                            </div>
                                                                                </div>
                                                                            </div>


                                                                            <div class="form-group row">
                                                                                <label
                                                                                    class="col-sm-2 col-form-label"></label>

                                                                                <div class="col-sm-10">
                                                                                    <?php if ($edit_state == false): ?>
                                                                                        <a href="orderappointment.php"
                                                                                            style="float:left">
                                                                                            <button type="submit"
                                                                                                name="btnsubmit"
                                                                                                class="btn waves-effect waves-light hor-grd btn-grd-primary ">Submit</button></a>&nbsp;&nbsp;&nbsp;
                                                                                                <input type="reset" class="btn waves-effect waves-light hor-grd btn-grd-primary " value="Reset">
                                                                                    <?php else: ?>
                                                                                        <a href="orderappointment.php"
                                                                                            style="float:left">
                                                                                            <button type="submit"
                                                                                                name="btnupdate"
                                                                                                class="btn waves-effect waves-light hor-grd btn-grd-primary ">Update</button></a>
                                                                                                <a href="orderappointment.php" style="float:left; margin-left: 10px;">
                                                                                                <button type="button"  class="btn waves-effect waves-light hor-grd btn-grd-danger">Cancel</button>
                                                                                            </a>
                                                                                                
                                                                                    <?php endif ?>
                                                                                </div>
                                                                            </div>

                                                                        </div><br>
                                                                        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
                                                         


                                                                    </form>
                                                                    <?php
                                                                      include "connect.php";

                                                                      // Insert The record In database With Validation
                                                                      if (isset($_POST["btnsubmit"])) {
                                                                          $ord_id = $_POST['ord_id'];
                                                                          $appointment_date = $_POST['appointment_date'];
                                                                          $appointment_detail = $_POST['appointment_detail'];
                                                                          $appointment_time = $_POST['appointment_time'];
                                                                          $appointment_address = $_POST['appointment_address'];
                                                                          $remark = $_POST['remark'];
                                                                          $app_status = $_POST['app_status'];
                                                                      
                                                                          $uploadDirectory = "uploads/";
                                                                      
                                                                          if (!is_dir($uploadDirectory)) {
                                                                              mkdir($uploadDirectory, 0755, true);
                                                                          }
                                                                      
                                                                          $allowedExtensions = ['pdf', 'doc', 'docx'];
                                                                          $appointment_doc = [];
                                                                      
                                                                          foreach ($_FILES["files"]["tmp_name"] as $key => $tmpFile) {
                                                                              $originalappointment_doc = $_FILES["files"]["name"][$key];
                                                                              $fileExtension = pathinfo($originalappointment_doc, PATHINFO_EXTENSION);
                                                                      
                                                                              // Validate file extension
                                                                              if (in_array($fileExtension, $allowedExtensions)) {
                                                                                  $uniqueappointment_doc = uniqid() . '_' . $originalappointment_doc;
                                                                                  $targetFilePath = $uploadDirectory . $uniqueappointment_doc;
                                                                      
                                                                                  if (move_uploaded_file($tmpFile, $targetFilePath)) {
                                                                                      $appointment_doc[] = $targetFilePath;
                                                                                  } else {
                                                                                      echo "<script>";
                                                                                      echo 'alert("File Upload Error.");';
                                                                                      echo 'window.location.href="orderappointment.php";';
                                                                                      echo "</script>";
                                                                                  }
                                                                              } else {
                                                                                  echo "<script>";
                                                                                  echo 'alert("Invalid file format. Allowed formats: PDF, DOC, DOCX.");';
                                                                                  echo 'window.location.href="orderappointment.php";';
                                                                                  echo "</script>";
                                                                              }
                                                                          }
                                                                      
                                                                          if (!empty($appointment_doc)) {
                                                                              $appointment_docJson = json_encode($appointment_doc);
                                                                      
                                                                              $sql = "INSERT INTO order_appointment (ord_id,appointment_date, appointment_detail,appointment_time, appointment_address,appointment_doc, remark, app_status) 
                                                                                      VALUES ('$ord_id','$appointment_date', '$appointment_detail','$appointment_time', '$appointment_address','$appointment_docJson', '$remark','$app_status')";
                                                                      
                                                                              if ($conn->query($sql) === true) {
                                                                                echo "<script>";
                                                                                echo 'alert("Record insert Successfully");';
                                                                                echo 'window.location.href="orderappointment.php";';
                                                                                echo "</script>";
                                                                              } else {
                                                                                echo "<script>";
                                                                                echo 'alert("Error");';
                                                                                echo 'window.location.href="orderappointment.php";';
                                                                                echo "</script>";
                                                                              }
                                                                          }
                                                                      }

                                                                     // Update The record In databse With Validation

                                                                    if (isset($_POST["btnupdate"])) {
                                                                        $appointment_id = $_POST["appointment_id"];
                                                                        // $user_name = $_POST["user_name"];
                                                                        $ord_id = $_POST['ord_id'];
                                                                        $appointment_id = $_POST['appointment_id'];
                                                                        $appointment_date = $_POST['appointment_date'];
                                                                        $appointment_detail = $_POST['appointment_detail'];
                                                                        $appointment_time = $_POST['appointment_time'];
                                                                        $appointment_address = $_POST['appointment_address'];
                                                                        $appointment_doc = $_POST["filePathsJson"];

                                                                        $remark = $_POST['remark'];
                                                                        $app_status = $_POST['app_status'];
                                    
                                                                        $uploadDirectory = "uploads/";
                                                                    
                                                                        if (!is_dir($uploadDirectory)) {
                                                                            mkdir($uploadDirectory, 0755, true);
                                                                        }
                                                                        $sql = "SELECT appointment_doc FROM order_appointment WHERE appointment_id='$appointment_id'";
                                                                        $result1 = $conn->query($sql);
                                                                        if ($result1->num_rows > 0) {
                                                                            while($row = $result1->fetch_assoc()) {
                                                                                $oldFilePathsJson = $row["appointment_doc"];
                                                                                $oldFilePaths = json_decode($oldFilePathsJson, true);
                                                                    
                                                                                // Delete old files
                                                                                foreach ($oldFilePaths as $oldFilePath) {
                                                                                    if (file_exists($oldFilePath)) {
                                                                                        unlink($oldFilePath);
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    
                                                                        $filePaths = [];
                                                                        $allowedExtensions = ['pdf', 'doc', 'docx'];
                                                                        // $appointment_doc = [];
                                                                    
                                                                        foreach ($_FILES["files"]["tmp_name"] as $key => $tmpFile) {
                                                                            $originalappointment_doc = $_FILES["files"]["name"][$key];
                                                                            $fileExtension = pathinfo($originalappointment_doc, PATHINFO_EXTENSION);
                                                                    
                                                                            // Validate file extension
                                                                            if (in_array($fileExtension, $allowedExtensions)) {
                                                                                $uniqueappointment_doc = uniqid() . '_' . $originalappointment_doc;
                                                                                $targetFilePath = $uploadDirectory . $uniqueappointment_doc;
                                                                    
                                                                                if (move_uploaded_file($tmpFile, $targetFilePath)) {
                                                                                    $filePaths[] = $targetFilePath;
                                                                                } else {
                                                                                    echo "<script>";
                                                                                    echo 'alert("File Upload Error.");';
                                                                                    echo 'window.location.href="orderappointment.php";';
                                                                                    echo "</script>";
                                                                                }
                                                                            } else {
                                                                                echo "<script>";
                                                                                echo 'alert("Invalid file format. Allowed formats: PDF, DOC, DOCX.");';
                                                                                echo 'window.location.href="orderappointment.php";';
                                                                                echo "</script>";
                                                                            }
                                                                        
                                                                        
                                                                    
                                                                        if (!empty($filePaths)) {
                                                                            $filePathsJson = json_encode($filePaths);
                                                                    
                                                                           
                                                                           $res = "UPDATE order_appointment SET ord_id='$ord_id', appointment_date='$appointment_date', appointment_detail='$appointment_detail', appointment_time='$appointment_time', appointment_address='$appointment_address', appointment_doc='$filePathsJson', remark='$remark', app_status='$app_status' WHERE appointment_id='$appointment_id'";

                                           
                                                                    
                                                                            if ($conn->query($res) === true) {
                                                                                echo "<script>";
                                                                                echo 'alert("File Updated in Database Successful.");';
                                                                                echo 'window.location.href="orderappointment.php";';
                                                                                echo "</script>";
                                                                            } else {
                                                                                echo "<script>";
                                                                                echo 'alert("File Not Updated in database.");';
                                                                                echo 'window.location.href="orderappointment.php";';
                                                                                echo "</script>";
                                                                            }
                                                                        } else {
                                                                           echo "<script>";
                                                                           echo 'alert("No file Selected.");';
                                                                           echo 'window.location.href="orderappointment.php";';
                                                                           echo "</script>";
                                                                        }
                                                                    } 

                                                                }

                                                                
                                                                if (isset($_GET['delete'])) {
                                                                    $appointment_id = $_GET['delete'];
                                                                
                                                                    // Fetch appointment_doc JSON from the database
                                                                    $result = $conn->query("SELECT appointment_doc FROM order_appointment WHERE appointment_id = $appointment_id");
                                                                
                                                                    if ($result->num_rows > 0) {
                                                                        $row = $result->fetch_assoc();
                                                                        $appointment_docJson = json_decode($row['appointment_doc'], true);
                                                                
                                                                        // Delete files associated with the record
                                                                        foreach ($appointment_docJson as $file) {
                                                                            if (file_exists($file)) {
                                                                                unlink($file); // Delete the file
                                                                            }
                                                                        }
                                                                
                                                                        // Delete the record from the database
                                                                        mysqli_query($conn, "DELETE FROM order_appointment WHERE appointment_id = $appointment_id");
                                                                
                                                                        echo '<script>';
                                                                        echo 'alert("Record and associated files Deleted Successfully.");';
                                                                        echo 'window.location.href="orderappointment.php";';
                                                                        echo '</script>';
                                                                    } else {
                                                                        echo '<script>';
                                                                        echo 'alert("Record not found.");';
                                                                        echo 'window.location.href="orderappointment.php";';
                                                                        echo '</script>';
                                                                    }
                                                                }

                                      
                                                             
                                                                if (isset($_GET['file']) && isset($_GET['appointment_id'])) {
                                                                    $fileToDelete = urldecode($_GET['file']);
                                                                    $appointment_id = $_GET['appointment_id'];

                                                                    // Delete the file from the folder
                                                                    if (unlink($fileToDelete)) {
                                                                        // File deleted successfully, now remove its reference from the database

                                                                        // Remove the file path from the appointment_doc JSON array in the database
                                                                        $sql = "SELECT appointment_doc FROM order_appointment WHERE appointment_id = $appointment_id";
                                                                        $result = $conn->query($sql);

                                                                        if ($result->num_rows > 0) {
                                                                            $row = $result->fetch_assoc();
                                                                            $filePaths = json_decode($row['appointment_doc'], true);
                                                                            $filePaths = array_diff($filePaths, [$fileToDelete]);

                                                                            // Update the database with the new appointment_doc JSON array
                                                                            $updatedFilePaths = json_encode(array_values($filePaths));
                                                                            $updateSql = "UPDATE order_appointment SET appointment_doc = '$updatedFilePaths' WHERE appointment_id = $appointment_id";

                                                                            if ($conn->query($updateSql) === TRUE) {
                                                                                echo '<script>';
                                                                                echo 'alert("File delete Successfully.");';
                                                                                echo 'window.location.href="orderappointment.php";';
                                                                                echo '</script>';
                                                                            } else {
                                                                                echo '<script>';
                                                                                echo 'alert("File Not Deleted.");';
                                                                                echo 'window.location.href="orderappointment.php";';
                                                                                echo '</script>';
                                                                            }
                                                                        } else {
                                                                            echo '<script>';
                                                                            echo 'alert("Appointment Not found.");';
                                                                            echo 'window.location.href="orderappointment.php";';
                                                                            echo '</script>';
                                                                        }

                                                                        $conn->close();
                                                                    } else {
                                                                    
                                                                    }
                                                                } else {
                                                                
                                                                }
                                                                ?>




                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Another section -->
                                        <div class="page-body">
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <!-- Default Date-Picker card start -->
                                                    <div class="card">
                                                        <div class="card-header">
                                                            <h3>Appointmant Details</h3>
                                                        </div>
                                                        <div class="card-block">
                                                            <div class="dt-responsive table-responsive">
                                                            <?php
                                       include 'connect.php';
                                       $sql = "SELECT * FROM order_appointment";
                                       $result = $conn->query($sql);
                                       
                                       if ($result->num_rows > 0) {
                                           echo '<table id="dom-table" class="table table-striped table-bordered nowrap">';
                                           echo '<thead>';
                                           echo '<tr>
                                           <th>Sr. no</th>
                                           <th>Appointment Id</th>
                                           <th>Order ID</th>
                                           <th>Appointment Date</th>
                                           <th>Appointment Detail</th>
                                           <th>Appointment Time</th>
                                           <th>Appointment Address</th>
                                           <th>Appointment Document And Downlaod</th>
                                           <th>remark</th>
                                           <th>Status</th>
                                           <th>Action</th>
                                           </tr>';
                                           echo '</thead>';
                                           echo '<tbody>';
                                       
                                           $serialNumber = 1; // Initialize serial number
                                       
                                           while ($row = $result->fetch_assoc()) {
                                              $appointment_id = $row["appointment_id"];
                                             echo '<tr>';
                                             echo "<td>" . $serialNumber . "</td>";
                                             echo "<td>" . $row["appointment_id"] . "</td>";
                                             echo "<td>" . $row["ord_id"] . "</td>";
                                             echo "<td>" . $row["appointment_date"] . "</td>";
                                             echo "<td style=' white-space: inherit;'>" . $row["appointment_detail"] . "</td>";
                                             echo "<td>" . date("h:i A", strtotime($row["appointment_time"])) . "</td>";
                                             echo "<td style=' white-space: inherit;'>" . $row["appointment_address"] . "</td>";
                                         
                                             // Decode the JSON data to get an array of file paths
                                             $filePaths= json_decode($row["appointment_doc"], true);
                                         
                                             echo '<td>';
                                             // Check if $filePaths array is empty
                                             if (empty($filePaths)) {
                                                 echo '<span style="color:red;">No Document Select</span>'; // Display null or any desired message
                                             } else {
                                                 // Iterate through each file path and create a download link
                                                 foreach ($filePaths as $filePath) {
                                                     // Extract the appointment_doc from the file path
                                                     $appointment_doc = basename($filePath);
                                                     // Create a download link
                                                     echo '<a href="' . $filePath . '" target="_blank"><i class="fa fa-file-text"></i>' . $appointment_doc . '</a><a href="orderappointment.php?file=' . urlencode($filePath) . '&appointment_id=' . $appointment_id . '" style="color:red;">&nbsp;&nbsp;<i class="fa fa-trash-o"></i></a><br>';
                                                 }
                                             }
                                             echo '</td>';
                                             
                                             echo "<td style=' white-space: inherit;'>" . $row["remark"] . "</td>";
                                             echo "<td>";
                                                if ($row['app_status'] == "Pending") {
                                                    echo "<label class='label label-default'>Pending</label>";
                                                } elseif ($row['app_status'] == "Cancel") {
                                                    echo "<label class='label label-danger'>Cancel</label>";
                                                } elseif ($row['app_status'] == "Successful") {
                                                    echo "<label class='label label-info'>successful</label>";
                                                } elseif ($row['app_status'] == "Active") {
                                                    echo "<label class='label label-primary'>Active</label>";
                                                } elseif ($row['app_status'] == "Inactive") {
                                                    echo "<label class='label label-warning'>Inactive</label>";
                                                } else {
                                                    echo "<label class='label label-default'>Unknown</label>";
                                                }
                                                echo "</td>";
                                         
                                             // Add edit and delete buttons as you did before
                                             echo '<td><a href="orderappointment.php?edit=' .  $appointment_id . '" ><button class="btn btn-primary waves-effect waves-light btn-sm" ><i class="ti-pencil">&nbsp;Edit</i></button></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                   <a href="orderappointment.php?delete=' .  $appointment_id . '" ><button class="btn btn-danger waves-effect waves-light btn-sm"><i class="ti-trash">&nbsp;Delete</i></button></a></td>';
                                             echo '</tr>';
                                         
                                             $serialNumber++; // Increment the serial number for the next row
                                         }
                                         
                                       
                                           echo '</tbody>';
                                           echo '</table>';
                                       } else {
                                           echo '<p>No Records Avaiable</p>';
                                       }
                                       ?>
                                                               

                                                                </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Page body end -->
                                    </div>
                                </div>
                                <!-- Main-body end -->
                                <div id="styleSelector">

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>











        <script>
            window.dataLayer = window.dataLayer || [];
            function gtag() { dataLayer.push(arguments); }
            gtag('js', new Date());

            gtag('config', 'UA-23581568-13');
        </script>
</body>


<!-- Mirrored from colorlib.com//polygon/admindek/default/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 23 Dec 2018 06:56:00 GMT -->

</html>
<!-- Required Jquery -->
<script type="text/javascript" src="bower_components/jquery/js/jquery.min.js"></script>
<script type="text/javascript" src="bower_components/jquery-ui/js/jquery-ui.min.js"></script>
<script type="text/javascript" src="bower_components/popper.js/js/popper.min.js"></script>
<script type="text/javascript" src="bower_components/bootstrap/js/bootstrap.min.js"></script>
<!-- waves js -->
<script src="assets/pages/waves/js/waves.min.js"></script>
<!-- jquery slimscroll js -->
<script type="text/javascript" src="bower_components/jquery-slimscroll/js/jquery.slimscroll.js"></script>
<!-- modernizr js -->
<script type="text/javascript" src="bower_components/modernizr/js/modernizr.js"></script>
<script type="text/javascript" src="bower_components/modernizr/js/css-scrollbars.js"></script>
<!-- Float Chart js -->
<script src="assets/pages/chart/float/jquery.flot.js"></script>
<script src="assets/pages/chart/float/jquery.flot.categories.js"></script>
<script src="assets/pages/chart/float/curvedLines.js"></script>
<script src="assets/pages/chart/float/jquery.flot.tooltip.min.js"></script>
<!-- Chartlist charts -->
<script src="bower_components/chartist/js/chartist.js"></script>
<!-- amchart js -->
<script src="assets/pages/widget/amchart/amcharts.js"></script>
<script src="assets/pages/widget/amchart/serial.js"></script>
<script src="assets/pages/widget/amchart/light.js"></script>
<!-- Custom js -->
<script src="assets/js/pcoded.min.js"></script>
<script src="assets/js/vertical/vertical-layout.min.js"></script>
<script type="text/javascript" src="assets/pages/dashboard/custom-dashboard.min.js"></script>
<script type="text/javascript" src="assets/js/script.min.js"></script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>

<!-- Select 2 js -->
<script type="text/javascript" src="bower_components/select2/js/select2.full.min.js"></script>
<!-- Multiselect js -->
<script type="text/javascript" src="bower_components/bootstrap-multiselect/js/bootstrap-multiselect.js"></script>
<script type="text/javascript" src="bower_components/multiselect/js/jquery.multi-select.js"></script>
<script type="text/javascript" src="assets/js/jquery.quicksearch.js"></script>
<!-- Custom js -->
<script type="text/javascript" src="assets/pages/advance-elements/select2-custom.js"></script>

<!-- Bootstrap date-time-picker js -->
<script type="text/javascript" src="assets/pages/advance-elements/moment-with-locales.min.js"></script>
<script type="text/javascript" src="bower_components/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
<script type="text/javascript" src="assets/pages/advance-elements/bootstrap-datetimepicker.min.js"></script>
<!-- Date-range picker js -->
<script type="text/javascript" src="bower_components/bootstrap-daterangepicker/js/daterangepicker.js"></script>
<!-- Date-dropper js -->
<script type="text/javascript" src="bower_components/datedropper/js/datedropper.min.js"></script>
<!-- Color picker js -->
<script type="text/javascript" src="bower_components/spectrum/js/spectrum.js"></script>
<script type="text/javascript" src="bower_components/jscolor/js/jscolor.js"></script>
<!-- Mini-color js -->
<script type="text/javascript" src="bower_components/jquery-minicolors/js/jquery.minicolors.min.js"></script>
<!-- Custom js -->
<script type="text/javascript" src="assets/pages/advance-elements/custom-picker.js"></script>

<!-- data-table js -->
<script src="bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="bower_components/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="assets/pages/data-table/js/jszip.min.js"></script>
<script src="assets/pages/data-table/js/pdfmake.min.js"></script>
<script src="assets/pages/data-table/js/vfs_fonts.js"></script>
<script src="bower_components/datatables.net-buttons/js/buttons.print.min.js"></script>
<script src="bower_components/datatables.net-buttons/js/buttons.html5.min.js"></script>
<script src="bower_components/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="bower_components/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
<script src="bower_components/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>
<!-- Custom js -->
<script src="assets/pages/data-table/js/data-table-custom.js"></script>
<script src="assets/js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="assets/js/script.js"></script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>