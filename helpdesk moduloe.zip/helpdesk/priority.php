<?php
    // session_start();
    include 'connect.php';
    $edit_state = false;
    if (isset($_GET['edit'])) 
    {
		$priority_id  = $_GET['edit'];
		$edit_state = true;

		$res = mysqli_query($conn, "SELECT * FROM priority_master WHERE priority_id =$priority_id ");
        $data = mysqli_fetch_array($res);

        $priority_name=$data['priority_name'];
        $priority_desci=$data['priority_desci'];
       
        
    }
?>


<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

<head>
    <title>Admindek | Admin Template</title>
    <!-- HTML5 Shim and Respond.js IE10 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 10]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    <!-- Meta -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="description"
        content="Admindek Bootstrap admin template made using Bootstrap 4 and it has huge amount of ready made feature, UI components, pages which completely fulfills any dashboard needs." />
    <meta name="keywords"
        content="flat ui, admin Admin , Responsive, Landing, Bootstrap, App, Template, mobileno, iOS, Android, apple, creative app">
    <meta name="author" content="colorlib" />
    <link rel="stylesheet" href="icon.css">
    <link rel="icon" href="https://colorlib.com//polygon/admindek/files/assets/images/favicon.ico" type="image/x-icon">
    <!-- Google font-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Quicksand:500,700" rel="stylesheet">
    <!-- Required Framework -->
    <link rel="stylesheet" type="text/css" href="bower_components/bootstrap/css/bootstrap.min.css">
    <!-- waves.css -->
    <link rel="stylesheet" href="assets/pages/waves/css/waves.min.css" type="text/css" media="all">
    <!-- feather icon -->
    <link rel="stylesheet" type="text/css" href="assets/icon/feather/css/feather.css">
    <!-- font-awesome-n -->
    <link rel="stylesheet" type="text/css" href="assets/css/font-awesome-n.min.css">
    <!-- Chartlist chart CSS -->
    <link rel="stylesheet" href="bower_components/chartist/css/chartist.css" type="text/css" media="all">
    <!-- Style.css -->
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="assets/css/widget.css">
    <!-- themify-icons line icon -->
    <link rel="stylesheet" type="text/css" href="assets/icon/themify-icons/themify-icons.css">
    <!-- ico font -->
    <link rel="stylesheet" type="text/css" href="assets/icon/icofont/css/icofont.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" type="text/css" href="assets/icon/font-awesome/css/font-awesome.min.css">
    <!-- Date-time picker CSS -->
    <link rel="stylesheet" type="text/css" href="assets/pages/advance-elements/css/bootstrap-datetimepicker.css">
    <!-- Date-range picker CSS -->
    <link rel="stylesheet" type="text/css" href="bower_components/bootstrap-daterangepicker/css/daterangepicker.css" />
    <!-- Date-Dropper CSS -->
    <link rel="stylesheet" type="text/css" href="bower_components/datedropper/css/datedropper.min.css" />
    <!-- Color Picker CSS -->
    <link rel="stylesheet" type="text/css" href="bower_components/spectrum/css/spectrum.css" />
    <!-- Mini-color CSS -->
    <link rel="stylesheet" type="text/css" href="bower_components/jquery-minicolors/css/jquery.minicolors.css" />
    <!-- Select 2 CSS -->
    <link rel="stylesheet" href="bower_components/select2/css/select2.min.css" />
    <!-- Multi Select CSS -->
    <link rel="stylesheet" type="text/css"
        href="bower_components/bootstrap-multiselect/css/bootstrap-multiselect.css" />
    <link rel="stylesheet" type="text/css" href="bower_components/multiselect/css/multi-select.css" />
    <!-- Forms-wizard CSS -->
    <link rel="stylesheet" type="text/css" href="bower_components/jquery.steps/css/jquery.steps.css">
    <!-- Data Table Css -->
    <link rel="stylesheet" type="text/css" href="bower_components/datatables.net-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" type="text/css" href="assets/pages/data-table/css/buttons.dataTables.min.css">
    <link rel="stylesheet" type="text/css"
        href="bower_components/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css">
    <link rel="icon" href="https://colorlib.com//polygon/admindek/files/assets/images/favicon.ico" type="image/x-icon">
    <!-- Switch component css -->
    <link rel="stylesheet" type="text/css" href="bower_components/switchery/css/switchery.min.css">
    <!-- Tags css -->
    <link rel="stylesheet" type="text/css" href="bower_components/bootstrap-tagsinput/css/bootstrap-tagsinput.css" />


    <link rel="icon" href="https://colorlib.com//polygon/admindek/files/assets/images/favicon.ico" type="image/x-icon">
    <!-- Bootstrap Modalsgle font-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Quicksand:500,700" rel="stylesheet">
    <!-- Required Fremwork -->
    <link rel="stylesheet" type="text/css" href="bower_components/bootstrap/css/bootstrap.min.css">
    <!-- waves.css -->
    <link rel="stylesheet" href="assets/pages/waves/css/waves.min.css" type="text/css" media="all">
    <!-- feather icon -->
    <link rel="stylesheet" type="text/css" href="assets/icon/feather/css/feather.css">
    <!-- sweet alert framework -->
    <link rel="stylesheet" type="text/css" href="bower_components/sweetalert/css/sweetalert.css">
    <!-- themify-icons line icon -->
    <link rel="stylesheet" type="text/css" href="assets/icon/themify-icons/themify-icons.css">
    <!-- ico font -->
    <link rel="stylesheet" type="text/css" href="assets/icon/icofont/css/icofont.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" type="text/css" href="assets/icon/font-awesome/css/font-awesome.min.css">
    <!-- animation nifty modal window effects css -->
    <link rel="stylesheet" type="text/css" href="assets/css/component.css">
    <!-- Style.css -->
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="assets/css/pages.css">
    <style>
        .passphoto {
            width: 140px;
            height: 140px;
            border: 2px solid #ccc;
            display: flex;
            justify-content: center;
            align-items: center;
            overflow: hidden;
            position: absolute;
            top: -8%;
            right: 0%;
        }

        img {
            max-width: 100%;
            max-height: 100%;
            object-fit: cover;
        }
    </style>



</head>

<body>
    <!-- [ Pre-loader ] start -->
    <div class="loader-bg">
        <div class="loader-bar"></div>
    </div>
    <!-- [ Pre-loader ] end -->
    <div id="pcoded" class="pcoded">
        <div class="pcoded-overlay-box"></div>
        <div class="pcoded-container navbar-wrapper">
            <!-- [ Header ] start -->
            <nav class="navbar header-navbar pcoded-header">
                <div class="navbar-wrapper">
                    <div class="navbar-logo">
                        <a href="index.html">
                            <img class="img-fluid" src="assets/images/logo.png" alt="Theme-Logo" />
                        </a>
                        <a class="mobile-menu" id="mobile-collapse" href="#!">
                            <i class="feather icon-menu icon-toggle-right"></i>
                        </a>
                        <a class="mobile-options waves-effect waves-light">
                            <i class="feather icon-more-horizontal"></i>
                        </a>
                    </div>
                    <div class="navbar-container container-fluid">
                        <ul class="nav-left">
                            <li class="header-search">
                                <div class="main-search morphsearch-search">
                                    <div class="input-group">
                                        <span class="input-group-prepend search-close">
                                            <i class="feather icon-x input-group-text"></i>
                                        </span>
                                        <input type="text" class="form-control" placeholder="Enter Keyword">
                                        <span class="input-group-append search-btn">
                                            <i class="feather icon-search input-group-text"></i>
                                        </span>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <a href="#!" onclick="javascript:toggleFullScreen()" class="waves-effect waves-light">
                                    <i class="full-screen feather icon-maximize"></i>
                                </a>
                            </li>
                        </ul>
                        <ul class="nav-right">
                            <li class="header-notification">
                                <div class="dropdown-primary dropdown">
                                    <div class="dropdown-toggle" data-toggle="dropdown">
                                        <i class="feather icon-bell"></i>
                                        <span class="badge bg-c-red">5</span>
                                    </div>
                                    <ul class="show-notification notification-view dropdown-menu"
                                        data-dropdown-in="fadeIn" data-dropdown-out="fadeOut">
                                        <li>
                                            <h6>Notifications</h6>
                                            <label class="label label-danger">New</label>
                                        </li>
                                        <li>
                                            <div class="media">
                                                <img class="img-radius" src="assets/images/avatar-4.jpg"
                                                    alt="Generic placeholder image">
                                                <div class="media-body">
                                                    <h5 class="notification-user">John Doe</h5>
                                                    <p class="notification-msg">Lorem ipsum dolor sit amet, consectetuer
                                                        elit.</p>
                                                    <span class="notification-time">30 minutes ago</span>
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="media">
                                                <img class="img-radius" src="assets/images/avatar-3.jpg"
                                                    alt="Generic placeholder image">
                                                <div class="media-body">
                                                    <h5 class="notification-user">Joseph William</h5>
                                                    <p class="notification-msg">Lorem ipsum dolor sit amet, consectetuer
                                                        elit.</p>
                                                    <span class="notification-time">30 minutes ago</span>
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="media">
                                                <img class="img-radius" src="assets/images/avatar-4.jpg"
                                                    alt="Generic placeholder image">
                                                <div class="media-body">
                                                    <h5 class="notification-user">Sara Soudein</h5>
                                                    <p class="notification-msg">Lorem ipsum dolor sit amet, consectetuer
                                                        elit.</p>
                                                    <span class="notification-time">30 minutes ago</span>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="header-notification">
                                <div class="dropdown-primary dropdown">
                                    <div class="displayChatbox dropdown-toggle" data-toggle="dropdown">
                                        <i class="feather icon-message-square"></i>
                                        <span class="badge bg-c-green">3</span>
                                    </div>
                                </div>
                            </li>
                            <li class="user-profile header-notification">

                                <div class="dropdown-primary dropdown">
                                    <div class="dropdown-toggle" data-toggle="dropdown">
                                        <img src="assets/images/avatar-4.jpg" class="img-radius"
                                            alt="User-Profile-Image">
                                        <span>John Doe</span>
                                        <i class="feather icon-chevron-down"></i>
                                    </div>
                                    <ul class="show-notification profile-notification dropdown-menu"
                                        data-dropdown-in="fadeIn" data-dropdown-out="fadeOut">
                                        <li>
                                            <a href="#!">
                                                <i class="feather icon-settings"></i> Settings

                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <i class="feather icon-user"></i> Profile

                                            </a>
                                        </li>
                                        <li>
                                            <a href="email-inbox.html">
                                                <i class="feather icon-mail"></i> My Messages

                                            </a>
                                        </li>
                                        <li>
                                            <a href="auth-lock-screen.html">
                                                <i class="feather icon-lock"></i> Lock Screen

                                            </a>
                                        </li>
                                        <li>
                                            <a href="auth-sign-in-social.html">
                                                <i class="feather icon-log-out"></i> Logout

                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <!-- [ chat user list ] start -->
            <div id="sidebar" class="users p-chat-user showChat">
                <div class="had-container">
                    <div class="p-fixed users-main">
                        <div class="user-box">
                            <div class="chat-search-box">
                                <a class="back_friendlist">
                                    <i class="feather icon-x"></i>
                                </a>
                                <div class="right-icon-control">
                                    <div class="input-group input-group-button">
                                        <input type="text" id="search-friends" name="footer-email" class="form-control"
                                            placeholder="Search Friend">
                                        <div class="input-group-append">
                                            <button class="btn btn-primary waves-effect waves-light" type="button"><i
                                                    class="feather icon-search"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="main-friend-list">
                                <div class="media userlist-box waves-effect waves-light" data-id="1"
                                    data-status="online" data-username="Josephin Doe">
                                    <a class="media-left" href="#!">
                                        <img class="media-object img-radius img-radius" src="assets/images/avatar-3.jpg"
                                            alt="Generic placeholder image ">
                                        <div class="live-status bg-success"></div>
                                    </a>
                                    <div class="media-body">
                                        <div class="chat-header">Josephin Doe</div>
                                    </div>
                                </div>
                                <div class="media userlist-box waves-effect waves-light" data-id="2"
                                    data-status="online" data-username="Lary Doe">
                                    <a class="media-left" href="#!">
                                        <img class="media-object img-radius" src="assets/images/avatar-2.jpg"
                                            alt="Generic placeholder image">
                                        <div class="live-status bg-success"></div>
                                    </a>
                                    <div class="media-body">
                                        <div class="f-13 chat-header">Lary Doe</div>
                                    </div>
                                </div>
                                <div class="media userlist-box waves-effect waves-light" data-id="3"
                                    data-status="online" data-username="Alice">
                                    <a class="media-left" href="#!">
                                        <img class="media-object img-radius" src="assets/images/avatar-4.jpg"
                                            alt="Generic placeholder image">
                                        <div class="live-status bg-success"></div>
                                    </a>
                                    <div class="media-body">
                                        <div class="f-13 chat-header">Alice</div>
                                    </div>
                                </div>
                                <div class="media userlist-box waves-effect waves-light" data-id="4"
                                    data-status="offline" data-username="Alia">
                                    <a class="media-left" href="#!">
                                        <img class="media-object img-radius" src="assets/images/avatar-3.jpg"
                                            alt="Generic placeholder image">
                                        <div class="live-status bg-default"></div>
                                    </a>
                                    <div class="media-body">
                                        <div class="f-13 chat-header">Alia<small class="d-block text-muted">10 min
                                                ago</small></div>
                                    </div>
                                </div>
                                <div class="media userlist-box waves-effect waves-light" data-id="5"
                                    data-status="offline" data-username="Suzen">
                                    <a class="media-left" href="#!">
                                        <img class="media-object img-radius" src="assets/images/avatar-2.jpg"
                                            alt="Generic placeholder image">
                                        <div class="live-status bg-default"></div>
                                    </a>
                                    <div class="media-body">
                                        <div class="f-13 chat-header">Suzen<small class="d-block text-muted">15 min
                                                ago</small></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ chat user list ] end -->

            <!-- [ chat message ] start -->
            <div class="showChat_inner">
                <div class="media chat-inner-header">
                    <a class="back_chatBox">
                        <i class="feather icon-x"></i> Josephin Doe
                    </a>
                </div>
                <div class="main-friend-chat">
                    <div class="media chat-messages">
                        <a class="media-left photo-table" href="#!">
                            <img class="media-object img-radius img-radius m-t-5" src="assets/images/avatar-2.jpg"
                                alt="Generic placeholder image">
                        </a>
                        <div class="media-body chat-menu-content">
                            <div class="">
                                <p class="chat-cont">I'm just looking around. Will you tell me something about yourself?
                                </p>
                            </div>
                            <p class="chat-time">8:20 a.m.</p>
                        </div>
                    </div>
                    <div class="media chat-messages">
                        <div class="media-body chat-menu-reply">
                            <div class="">
                                <p class="chat-cont">Ohh! very nice</p>
                            </div>
                            <p class="chat-time">8:22 a.m.</p>
                        </div>
                    </div>
                    <div class="media chat-messages">
                        <a class="media-left photo-table" href="#!">
                            <img class="media-object img-radius img-radius m-t-5" src="assets/images/avatar-2.jpg"
                                alt="Generic placeholder image">
                        </a>
                        <div class="media-body chat-menu-content">
                            <div class="">
                                <p class="chat-cont">can you come with me?</p>
                            </div>
                            <p class="chat-time">8:20 a.m.</p>
                        </div>
                    </div>
                </div>
                <div class="chat-reply-box">
                    <div class="right-icon-control">
                        <div class="input-group input-group-button">
                            <input type="text" class="form-control" placeholder="Write hear . . ">
                            <div class="input-group-append">
                                <button class="btn btn-primary waves-effect waves-light" type="button"><i
                                        class="feather icon-message-circle"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ chat message ] end -->


            <div class="pcoded-main-container">
                <div class="pcoded-wrapper">
                    <!-- [ navigation menu ] start -->
                    <nav class="pcoded-navbar">

                        <div class="nav-list">
                            <div class="pcoded-inner-navbar main-menu">
                                <div class="pcoded-navigation-label"></div>
                                <ul class="pcoded-item pcoded-left-item">
                                    <li class="pcoded-hasmenu">
                                    <a href="javascript:void(0)" class="waves-effect waves-dark">
                                            <span class="pcoded-micon"><i class="feather icon-home"></i></span>
                                            <span class="pcoded-mtext">Dashboard</span>
                                        </a>
                                        <ul class="pcoded-submenu">
                                            <li class="">
                                                <a href="priority.php" class="waves-effect waves-dark">
                                                    <span class="pcoded-mtext">priority Deatils</span>
                                                </a>
                                            </li>
                                            <li class="">
                                                <a href="query.php" class="waves-effect waves-dark">
                                                    <span class="pcoded-mtext">Query Deatils</span>
                                                </a>
                                            </li>
                                            <li class="">
                                                <a href="orderappointment.php" class="waves-effect waves-dark">
                                                    <span class="pcoded-mtext">Appointmant Form</span>
                                                </a>
                                            </li>
                                            
                                        </ul>
                                    </li>

                                    </li>
                                </ul>

                            </div>
                        </div>
                    </nav>
                    <!-- [ navigation menu ] end -->
                    <div class="pcoded-content">
                        <!-- [ breadcrumb ] start -->
                        <div class="page-header card">
                            <div class="row align-items-end">
                                <div class="col-lg-8">
                                    <div class="page-header-title">
                                        <i class="feather icon-clipboard bg-c-blue"></i>
                                        <div class="d-inline">
                                            <h5>Priority Details</h5>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <!-- [ breadcrumb ] end -->



                        <div class="pcoded-inner-content">
                            <div class="main-body">
                                <div class="page-wrapper">
                                    <!-- Page body start -->
                                    <div class="page-body">
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <!-- Form wizard with validation card start -->
                                                <div class="card">
                                                    <div class="card-header">
                                                        <h5>Priority Details</h5>
                                                        
                                                    </div>
                                                    <div class="card-block">
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div id="wizard">




                                                                    <form method="post" action="priority.php">
                                                                      <input type="hidden" name="priority_id" value="<?php echo $priority_id; ?>">

                                                                        <div class="card-block">
                                                                            <div class="form-group row">
                                                                                <label
                                                                                    class="col-sm-2 col-form-label">Priority
                                                                                    Name</label>
                                                                                <div class="col-sm-10">
                                                                                    <input type="text"
                                                                                        name="priority_name" required
                                                                                        placeholder="Priority Name"
                                                                                        value="<?php if (isset($data['priority_name'])) {
                                                                                            echo $data['priority_name'];
                                                                                        } ?>"
                                                                                        class="form-control">
                                                                                </div>
                                                                            </div>
                                                                            <div class="form-group row">
                                                                                <label
                                                                                    class="col-sm-2 col-form-label">Priority
                                                                                    Description</label>
                                                                                <div class="col-sm-10">
                                                                                    <textarea name="priority_desci"
                                                                                        class="form-control" Required placeholder="Priority Description"
                                                                                        id="inputAddress" rows="3"><?php if (isset($data['priority_desci'])) {
                                                                                            echo $data['priority_desci'];
                                                                                        } ?></textarea>
                                                                                </div>
                                                                            </div>


                                                                            <div class="form-group row">
                                                                                <label
                                                                                    class="col-sm-2 col-form-label"></label>

                                                                                <div class="col-sm-10">
                                                                                    <?php if ($edit_state == false): ?>
                                                                                        <a href="priority.php"
                                                                                            style="float:left">
                                                                                        <button type="submit"
                                                                                            name="btnSubmit"
                                                                                            class="btn waves-effect waves-light hor-grd btn-grd-primary ">Submit</button></a>
                                                                                    <?php else: ?>
                                                                                        <a href="priority.php"
                                                                                            style="float:left">
                                                                                            <button type="submit"
                                                                                                name="btnUpdate"
                                                                                                class="btn waves-effect waves-light hor-grd btn-grd-primary ">Update</button></a>
                                                                                        <?php endif ?>
                                                                                </div>
                                                                            </div>

                                                                        </div><br>
                                                                    </form>
                                                                    <?php
                                                                            include 'connect.php';

                                                                            // For inserting records
                                                                            if (isset($_POST['btnSubmit'])) {
                                                                                $priority_name = $_POST['priority_name'];
                                                                                $priority_desci = $_POST['priority_desci'];

                                                                                // SQL query for inserting records
                                                                                $sql = "INSERT INTO priority_master (priority_name, priority_desci)
                                                                                        VALUES ('$priority_name', '$priority_desci')";

                                                                                if ($conn->query($sql) === TRUE) {
                                                                                    echo "<script>alert('Record Inserted Successfully');</script>";
                                                                                    // Redirect to the form page
                                                                                    echo '<script>window.location.href="priority.php"</script>';
                                                                                } else {
                                                                                    echo "<script>alert('Please try again');</script>";
                                                                                }
                                                                            }

                                                                            // For updating records
                                                                            if (isset($_POST['btnUpdate'])) {
                                                                                $priority_id = $_POST['priority_id'];
                                                                                $priority_name = $_POST['priority_name'];
                                                                                $priority_desci = $_POST['priority_desci'];

                                                                                // SQL query for updating records
                                                                                $res="update priority_master set priority_name='$priority_name',priority_desci='$priority_desci' where priority_id='$priority_id'";

                                                                                $result = mysqli_query($conn, $res);

                                                                                if ($result) {
                                                                                    echo '<script>';
                                                                                    echo 'alert("Record Updated Successfully.");';
                                                                                    echo 'window.location.href="priority.php";';
                                                                                    echo '</script>';
                                                                                } else {
                                                                                    echo "<script>alert('Please try again');</script>";
                                                                                }
                                                                            }

                                                                            // For deleting records
                                                                            if (isset($_GET['delete'])) {
                                                                                $priority_id = $_GET['delete'];
                                                                                // SQL query for deleting records
                                                                                mysqli_query($conn, "DELETE FROM priority_master WHERE priority_id=$priority_id");
                                                                                echo '<script>';
                                                                                echo 'alert("Record Deleted Successfully.");';
                                                                                echo 'window.location.href="priority.php";';
                                                                                echo '</script>';
                                                                            }
                                                                            ?>




                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                            <!-- Another section -->
                            <div class="page-body">
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <!-- Default Date-Picker card start -->
                                                <div class="card">
                                                    <div class="card-header">
                                                        <h3>Priority Details</h3>
                                                    </div>
                                                        <div class="card-block">
                                                            <div class="dt-responsive table-responsive">
                                                                <?php
                                                                $sql = "SELECT * FROM priority_master";
                                                                $result = $conn->query($sql);

                                                                if ($result->num_rows > 0) {
                                                                    echo '<table id="dom-table" class="table table-striped table-bordered nowrap">';
                                                                    echo '<thead>';
                                                                    echo '<tr>
                                                                                    <th>Sr. no</th>
                                                                                    <th>Priority Name</th>
                                                                                    <th>Priority Description</th>
                                                                                   
                                                                                    <th>Action</th>
                                                                                </tr>';
                                                                    echo '</thead>';
                                                                    echo '<tbody>';

                                                                    $serialNumber = 1; // Initialize serial number
                                                                
                                                                    while ($row = $result->fetch_assoc()) {
                                                                        $priority_id = $row["priority_id"];
                                                                        echo '<tr>';
                                                                        echo "<td>" . $serialNumber . "</td>"; // Display the serial number
                                                                        // Inside the while loop where you display images
                                                                
                                                                        // Output other table data
                                                                        echo "<td>" . $row["priority_name"] . "</td>";
                                                                        echo "<td style='white-space: inherit;'>" . $row["priority_desci"] . "</td>";

                                                                        echo '<td><a href="priority.php?edit=' . $priority_id . '" class="text-primary"><i class="fa fa-edit"></i>&nbsp;&nbsp;Edit</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                                                        <a href="priority.php?delete=' . $priority_id . '" class="text-danger"><i class="fa fa-trash"></i>&nbsp;&nbsp;Delete</a></td>';
                                                                        echo '</tr>';


                                                                        $serialNumber++; // Increment the serial number for the next row
                                                                    }

                                                                    echo '</tbody>';
                                                                    echo '</table>';
                                                                } else {
                                                                    echo '<p>No Entries Avaiable</p>';
                                                                }
                                                                ?>
                                                           </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Page body end -->
                                </div>
                            </div>
                            <!-- Main-body end -->
                            <div id="styleSelector">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
                  
                               
                                                 








                        <script>
                            window.dataLayer = window.dataLayer || [];
                            function gtag() { dataLayer.push(arguments); }
                            gtag('js', new Date());

                            gtag('config', 'UA-23581568-13');
                        </script>
</body>


<!-- Mirrored from colorlib.com//polygon/admindek/default/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 23 Dec 2018 06:56:00 GMT -->

</html>
<!-- Required Jquery -->
<script type="text/javascript" src="bower_components/jquery/js/jquery.min.js"></script>
<script type="text/javascript" src="bower_components/jquery-ui/js/jquery-ui.min.js"></script>
<script type="text/javascript" src="bower_components/popper.js/js/popper.min.js"></script>
<script type="text/javascript" src="bower_components/bootstrap/js/bootstrap.min.js"></script>
<!-- waves js -->
<script src="assets/pages/waves/js/waves.min.js"></script>
<!-- jquery slimscroll js -->
<script type="text/javascript" src="bower_components/jquery-slimscroll/js/jquery.slimscroll.js"></script>
<!-- modernizr js -->
<script type="text/javascript" src="bower_components/modernizr/js/modernizr.js"></script>
<script type="text/javascript" src="bower_components/modernizr/js/css-scrollbars.js"></script>
<!-- Float Chart js -->
<script src="assets/pages/chart/float/jquery.flot.js"></script>
<script src="assets/pages/chart/float/jquery.flot.categories.js"></script>
<script src="assets/pages/chart/float/curvedLines.js"></script>
<script src="assets/pages/chart/float/jquery.flot.tooltip.min.js"></script>
<!-- Chartlist charts -->
<script src="bower_components/chartist/js/chartist.js"></script>
<!-- amchart js -->
<script src="assets/pages/widget/amchart/amcharts.js"></script>
<script src="assets/pages/widget/amchart/serial.js"></script>
<script src="assets/pages/widget/amchart/light.js"></script>
<!-- Custom js -->
<script src="assets/js/pcoded.min.js"></script>
<script src="assets/js/vertical/vertical-layout.min.js"></script>
<script type="text/javascript" src="assets/pages/dashboard/custom-dashboard.min.js"></script>
<script type="text/javascript" src="assets/js/script.min.js"></script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>

<!-- Select 2 js -->
<script type="text/javascript" src="bower_components/select2/js/select2.full.min.js"></script>
<!-- Multiselect js -->
<script type="text/javascript" src="bower_components/bootstrap-multiselect/js/bootstrap-multiselect.js"></script>
<script type="text/javascript" src="bower_components/multiselect/js/jquery.multi-select.js"></script>
<script type="text/javascript" src="assets/js/jquery.quicksearch.js"></script>
<!-- Custom js -->
<script type="text/javascript" src="assets/pages/advance-elements/select2-custom.js"></script>

<!-- Bootstrap date-time-picker js -->
<script type="text/javascript" src="assets/pages/advance-elements/moment-with-locales.min.js"></script>
<script type="text/javascript" src="bower_components/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
<script type="text/javascript" src="assets/pages/advance-elements/bootstrap-datetimepicker.min.js"></script>
<!-- Date-range picker js -->
<script type="text/javascript" src="bower_components/bootstrap-daterangepicker/js/daterangepicker.js"></script>
<!-- Date-dropper js -->
<script type="text/javascript" src="bower_components/datedropper/js/datedropper.min.js"></script>
<!-- Color picker js -->
<script type="text/javascript" src="bower_components/spectrum/js/spectrum.js"></script>
<script type="text/javascript" src="bower_components/jscolor/js/jscolor.js"></script>
<!-- Mini-color js -->
<script type="text/javascript" src="bower_components/jquery-minicolors/js/jquery.minicolors.min.js"></script>
<!-- Custom js -->
<script type="text/javascript" src="assets/pages/advance-elements/custom-picker.js"></script>

<!-- data-table js -->
<script src="bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="bower_components/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="assets/pages/data-table/js/jszip.min.js"></script>
<script src="assets/pages/data-table/js/pdfmake.min.js"></script>
<script src="assets/pages/data-table/js/vfs_fonts.js"></script>
<script src="bower_components/datatables.net-buttons/js/buttons.print.min.js"></script>
<script src="bower_components/datatables.net-buttons/js/buttons.html5.min.js"></script>
<script src="bower_components/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="bower_components/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
<script src="bower_components/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>
<!-- Custom js -->
<script src="assets/pages/data-table/js/data-table-custom.js"></script>
<script src="assets/js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="assets/js/script.js"></script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>