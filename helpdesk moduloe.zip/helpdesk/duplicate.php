// Inside the loop where you display files for each appointment
echo '<a href="orderappointment.php?delete_file=' . $appointment_id . '&file_path=' . urlencode($filePath) . '">
      <button class="btn btn-danger waves-effect waves-light btn-sm">
      <i class="ti-close"></i>Delete File</button></a><br>';












      // At the beginning of your PHP script, before displaying appointments
if (isset($_GET['delete_file']) && isset($_GET['file_path'])) {
    $appointmentId = $_GET['delete_file'];
    $filePath = urldecode($_GET['file_path']);

    // Decode the JSON data from the database
    $sql = "SELECT appointment_doc FROM order_appointment WHERE appointment_id = $appointmentId";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $filePaths = json_decode($row['appointment_doc'], true);

        // Find and remove the specified file from the array
        $index = array_search($filePath, $filePaths);
        if ($index !== false) {
            unset($filePaths[$index]);

            // Update the appointment_doc field in the database with the modified JSON data
            $updatedFilePaths = json_encode(array_values($filePaths)); // Re-index the array
            $updateSql = "UPDATE order_appointment SET appointment_doc = '$updatedFilePaths' WHERE appointment_id = $appointmentId";
            if ($conn->query($updateSql) === TRUE) {
                // File deleted successfully
                header("Location: orderappointment.php"); // Redirect back to the appointments page
                exit();
            } else {
                // Error updating record
                echo "Error: " . $conn->error;
            }
        }
    }
}
