-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 14, 2023 at 12:26 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `helpdesk`
--

-- --------------------------------------------------------

--
-- Table structure for table `acadamicyear`
--

CREATE TABLE `acadamicyear` (
  `idacadamicyear` int(11) NOT NULL,
  `yearname` varchar(200) DEFAULT NULL,
  `year_abbr` varchar(200) DEFAULT NULL,
  `status` text DEFAULT NULL,
  `opn_date` date DEFAULT NULL,
  `cls_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `acadamicyear`
--

INSERT INTO `acadamicyear` (`idacadamicyear`, `yearname`, `year_abbr`, `status`, `opn_date`, `cls_date`) VALUES
(5, '2021-2022', '21-22', NULL, '2021-04-01', '2022-03-31'),
(6, '2022-2023', '22-23', NULL, '2022-04-01', '2023-03-31'),
(7, '2023-2024', '23-24', NULL, '2023-04-01', '2024-03-31');

-- --------------------------------------------------------

--
-- Table structure for table `companymaster`
--

CREATE TABLE `companymaster` (
  `comp_id` int(11) NOT NULL,
  `code` varchar(250) DEFAULT NULL,
  `comparnno` varchar(200) DEFAULT NULL,
  `comp_name` text DEFAULT NULL,
  `comp_owner` varchar(200) DEFAULT NULL,
  `comp_address` varchar(250) DEFAULT NULL,
  `comp_cont_no` varchar(200) DEFAULT NULL,
  `vat_ser_gst` varchar(200) DEFAULT NULL,
  `statename` varchar(11) DEFAULT NULL,
  `compfaxno` varchar(200) DEFAULT NULL,
  `compemailid` varchar(200) DEFAULT NULL,
  `comp_pan` varchar(200) DEFAULT NULL,
  `compcinno` varchar(200) DEFAULT NULL,
  `opening_balance` float DEFAULT NULL,
  `comp_logo` varchar(250) DEFAULT NULL,
  `terms_cond` text DEFAULT NULL,
  `mincount` int(11) DEFAULT NULL,
  `maxcount` int(11) DEFAULT NULL,
  `blankcount` int(11) DEFAULT NULL,
  `status` text DEFAULT NULL,
  `image_limit` int(11) DEFAULT NULL,
  `purchase_month` varchar(250) DEFAULT NULL,
  `print_logo` varchar(250) DEFAULT NULL,
  `bg_logo` varchar(250) DEFAULT NULL,
  `comp_city` text DEFAULT NULL,
  `comp_pin` int(11) DEFAULT NULL,
  `comp_web` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `companymaster`
--

INSERT INTO `companymaster` (`comp_id`, `code`, `comparnno`, `comp_name`, `comp_owner`, `comp_address`, `comp_cont_no`, `vat_ser_gst`, `statename`, `compfaxno`, `compemailid`, `comp_pan`, `compcinno`, `opening_balance`, `comp_logo`, `terms_cond`, `mincount`, `maxcount`, `blankcount`, `status`, `image_limit`, `purchase_month`, `print_logo`, `bg_logo`, `comp_city`, `comp_pin`, `comp_web`) VALUES
(6, '23SN09', '', 'SP CONCARE PVT. LTD.', 'Mr. Shrinivas Patil', 'CS NO. 1471. DB House 3rd Floor. Madhavnagar Road, Near Auto India, Sangli - 416416, Maharashtra, INDIA.', '9660896060', '27AAPCS5849D1ZW', '21', '+91 7073723737', 'info@spconcare.com', 'AAPCS5849D', 'MH29B0000707', 50000, 'ED1CFDEspc_logo.png', 'TERMS:\r\n1) Interest @24% p.a.will be charged if the bill is not paid within due date. \r\n2) Cheque return charges will be charged @ Rs.500/-  \r\n3) Objections, if any, be made within 7 days from the receipt of this bill.\r\n4) All grievances will be held at Sangli Jurisdiction.', 17, 5, 5, NULL, NULL, '12', '3DE1661spc_logo.jpeg', 'E93630B8184854spclogo.png', 'Sangli', 416416, 'www.spconcare.com'),
(7, '503EE03', '', 'SPC Nanofine', 'Mr. Shrinivas Patil', 'C/O Kakade Stone Crusher Gut No 227,  Mangrul, Tal - Maval , Dist - Pune. 410507', '9660896060', '27AAPCS5849D1ZW', '21', '+91 7073723737', 'info@spconcare.com', 'AAPCS5849D', 'MH29B0000707', 0, '0D9A5F2ED1CFDEspc_logo.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Pune', 410507, 'www.spconcare.com');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `iddepartment` int(11) NOT NULL,
  `depart_name` text DEFAULT NULL,
  `depart_abbr` varchar(200) DEFAULT NULL,
  `comp_id` varchar(110) DEFAULT NULL,
  `status` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`iddepartment`, `depart_name`, `depart_abbr`, `comp_id`, `status`) VALUES
(1, 'Sales and Marketing Department', 'S&amp;M', '6', ''),
(5, 'Manufacturing', 'Manufacturing', '6', ''),
(6, 'Office and Administration', 'Office and Administration', '6', ''),
(8, 'Fanchisee', 'FO', '6', NULL),
(9, 'Research &amp; Development', 'R&amp;D', '6', NULL),
(10, 'Store', 'ST', '6', NULL),
(11, 'Quality Control', 'QC', '6', NULL),
(12, 'HUMAN RESOURCE &amp; ADMINISTRATION', 'HR &amp; ADMIN', '6', NULL),
(13, 'Purchase', 'Purchase', '6', NULL),
(14, 'Account', 'Acc', '6', NULL),
(15, 'Sales', 'Sales', '6', NULL),
(16, 'Marketing', 'Marketing', '6', NULL),
(17, 'Maintenance', 'Maintenance', '6', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `employeemaster`
--

CREATE TABLE `employeemaster` (
  `idemployeemaster` int(11) NOT NULL,
  `code` varchar(200) DEFAULT NULL,
  `employeenm` varchar(200) DEFAULT NULL,
  `contact` varchar(250) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `postnm` int(11) DEFAULT NULL,
  `depart_abbr` varchar(200) NOT NULL,
  `dailywage` double DEFAULT NULL,
  `employeestatus` varchar(200) DEFAULT NULL,
  `employeepaymenttype` varchar(200) DEFAULT NULL,
  `employeemonthlysalary` double DEFAULT NULL,
  `sub_groupname` int(10) DEFAULT NULL,
  `comp_id` int(11) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `city` text DEFAULT NULL,
  `statename` int(11) DEFAULT NULL,
  `taxstatus` text DEFAULT NULL,
  `gender` text DEFAULT NULL,
  `email` text DEFAULT NULL,
  `pan_no` varchar(250) DEFAULT NULL,
  `dpphoto` varchar(250) DEFAULT NULL,
  `status` text DEFAULT NULL,
  `ref_contact` text DEFAULT NULL,
  `outlet_access` int(11) DEFAULT NULL,
  `usertype` varchar(250) DEFAULT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `employeemaster`
--

INSERT INTO `employeemaster` (`idemployeemaster`, `code`, `employeenm`, `contact`, `address`, `postnm`, `depart_abbr`, `dailywage`, `employeestatus`, `employeepaymenttype`, `employeemonthlysalary`, `sub_groupname`, `comp_id`, `birthdate`, `city`, `statename`, `taxstatus`, `gender`, `email`, `pan_no`, `dpphoto`, `status`, `ref_contact`, `outlet_access`, `usertype`, `username`, `password`) VALUES
(49, 'D17AC5', 'Akshay Hanmant Sawant', '9561921967', 'Main Road Radewadi, Ankalkhop, Tal Palus, Sangli. 416316', 11, '5', 846, 'Active', 'Monthly', 22000, 15, 6, '1994-11-14', 'Sangli', 21, 'Resident', 'Male', 'aksawant33@gmail.com', 'IZOPS7871G', NULL, '', '0', 3, NULL, 'pass123', 'pass123'),
(50, '920919', 'Anandrv Dattatray Patil', '8600591471', 'Jotiba Mandir Samor, Taluka Palus, Bambavade Bambavade , Sangli.', 14, '5', 1, 'Deactive', 'Monthly', 1, 15, 6, '1972-02-24', 'Sangli', 21, 'Resident', 'Male', '', 'BJIPP8770N', NULL, '', '0', 3, NULL, 'aa11', 'aa11'),
(51, '01DCA0', 'Sanjay Hanamant Pawar', '1', 'Madhala wada, Taluka Palus ,Bambavade Sangli.', 14, '5', 518, 'Active', 'Monthly', 14500, 15, 6, '1972-01-01', 'Sangli', 21, 'Resident', 'Male', '', 'DYIPP7280L', NULL, '', '0', 3, NULL, 'aa12', 'aa12'),
(52, 'AA75DD', 'Guruprasad Arvind Joshi', '7385048771', 'Panchashil nagar, MADHAVNAGAR ROAD, sangli', 15, '6', 446, 'Active', 'Monthly', 12500, 15, 6, '2018-05-05', 'SANGLI', 21, 'Resident', 'Male', '', 'BQEPJ0776M', NULL, '', '0', 1, NULL, 'aa13', 'aa13'),
(53, 'E0CAE8', 'Rajendra Dadaso Patil', '9922992163, 7588058895', 'Kavthepiran. Sangli.', 11, '5', 1, 'Deactive', 'Monthly', 17000, 15, 6, '1969-07-01', 'SANGLI', 21, 'Resident', 'Male', 'rajendra.patil@spconcare.com', 'CCGPP4037A', NULL, '', '0', 3, NULL, 'aa14', 'aa14'),
(54, '925FFD', 'Uday Patil', '9689002075', 'Trimurti ,chintamani nagar,MADHAVNAGAR ROAD CHINTAMANI NAGAR sagli.', 10, '6', 893, 'Active', 'Monthly', 25000, 15, 6, '1982-07-15', 'SANGLI', 21, 'Resident', 'Male', 'uday.patil@spconcare.com', 'AZVPP2384C', NULL, '', '0', 1, NULL, 'aa15', 'aa15'),
(55, '9DDE36', 'Ankita Baban Gavade', '7083645975', 'Near Datta temple, kadamwadi road, sangliwadi, sangli.', 13, '6', 440, 'Active', 'Monthly', 13200, 63, 6, '1997-02-13', 'Sangli', 21, 'Resident', 'Male', 'ankita.gavade@spconcare.com', 'BVRPG0344J', NULL, NULL, '7774081050', 1, NULL, 'aa16', 'aa16'),
(56, 'DA7665', 'Arshad Altaf Naikawadi', '91 8378833466', 'AT/PO: MALKAPUR TAL: SHAHUWADI\r\nDIST:  KOLHAPUR', 6, '1', 800, 'Deactive', 'Monthly', 25000, 63, 6, '1992-08-28', 'Kolhapur', 21, 'Resident', 'Male', 'arshad.naikawadi@spconcare.com', 'Asbpn455e', '3C57845harshad.jpg', NULL, '8387833466', 4, NULL, 'aa17', 'aa17'),
(57, 'C9AA8A', 'Shahid Bashir Karol', '9156984986', '0', 57, '1', 0, 'Active', 'Monthly', 40000, 63, 6, '1997-11-13', '9156984986', 21, 'Resident', 'Male', 'shahid.bashir@spconcare.com', '', '8336D10image.jpeg', NULL, 'Sangli', 1, NULL, 'aa18', 'aa18'),
(58, 'D5C646', 'Jitendra Suryan', '8433583707', 'Rasul Seth Chawl, Sahadeep Colony,\r\nP.L. Lokhande Road, Shop No.5,\r\nNear Chembur Station west', 6, '1', 1000, 'Deactive', 'Monthly', 30000, 63, 6, '2019-09-19', '8433583707', 21, 'Resident', 'Male', 'jitendra.suryan@spconcare.com', '', NULL, NULL, 'Pune', 1, NULL, 'aa19', 'aa19'),
(59, 'E48942', 'Harpal Singh Sodhi', '8087730534', 'Hajare bid. near millemum motors pune-mumbai road, Pune city, Dapodi ,Pune.', 6, '1', 800, 'Deactive', 'Monthly', 25000, 63, 6, '1979-04-18', '8087730534', 21, 'Resident', 'Male', 'harpal.sodhi@spconcare.com', 'DQYPS2012H', NULL, NULL, 'Pune', 1, NULL, 'qq1', 'qq1'),
(60, '6A09B2', 'Omkar Fadtare', '8411943004', 'Sangli', 8, '6', 0, 'Deactive', 'Monthly', 7000, 63, 6, '2020-02-28', 'Karthik Pawar', 21, 'Resident', 'Male', 'omkar@gmail.com', '', NULL, NULL, 'Sangli', 2, NULL, '', ''),
(61, 'A3EB81', 'Vishvjeet  Baburao Patil ( Outlet )', '9975109093, 9503337300', 'Shinde Galli A/P Kavathepiran Sangli 41416', 6, '8', 0, 'Active', 'Monthly', 10000, 63, 6, '2002-12-25', 'Sangli', 21, 'Resident', 'Male', 'vishvjeet.patil@spconcare.com', 'FITPP5563H', NULL, NULL, ' 0', 2, NULL, '', ''),
(62, '901F1A', 'Ganesh Shinde', '+919922616611', 'Rohini, Parshwanth Colony, Dhamani Road, Sangli 416416', 6, '8', 0, 'Deactive', 'Monthly', 0, 117, 6, '1979-09-09', 'Sagar Shinde 9823458707', 21, 'Resident', 'Male', 'ganesh.sangli@gmail.com', 'BDQPS2547L', NULL, NULL, 'Sangli', 2, NULL, '', ''),
(63, 'E726B4', 'Shubham Arun Mane', '8956978215', '752 E Shahupuri 4TH Lane balkrishna APT Shop. No.2. Kolhapur.416003', 6, '8', 0, 'Deactive', 'Monthly', 8000, 63, 6, '1996-08-06', 'Kolhapur', 21, 'Resident', 'Male', 'shubham.mane@spconcare.com', '', NULL, NULL, 'Kolhapur', 4, NULL, '', ''),
(64, 'FB06E7', 'Gandhar Santosh Malgundkar', '8421989831', 'Plot No 15, Miraj M.I.D.C., Road Mahabal Near, Miraj.', 12, '5', 300, 'Active', 'Monthly', 8000, 15, 6, '2021-02-04', '  Sangli', 21, 'Resident', 'Male', 'gandhar.malgundkar@spconcare.com', 'GGEPM1459R', NULL, NULL, ' 0', 3, NULL, '', ''),
(65, 'B1360F', 'Amruta Tanaji Patil', '8600212450', 'Bhairavnath Mandir Parisar nagthane , nagthane, Sangli', 12, '5', 300, 'Deactive', 'Monthly', 7000, 63, 6, '2021-02-04', 'Uday patil', 21, 'Resident', 'Female', '', '0', NULL, NULL, 'Sangli', 3, NULL, '', ''),
(66, '315C6E', 'Vinod Patil', '9822779845', 'Sangli 416 416', 8, '6', 0, 'Active', 'Monthly', 0, 63, 6, '0982-08-20', 'Sangli', 21, 'Resident', 'Male', 'cavinopatil@yahoo.in', '0', NULL, NULL, '0', 1, 'Admin', '', ''),
(67, '03E116', 'Krishna Solanke', '9175917743', '0', 7, '1', 1000, 'Deactive', 'Monthly', 30000, 63, 6, '2021-03-21', '0', 21, 'Resident', 'Male', 'krishna.sulanke@spconcare.com', '0', NULL, NULL, 'Solahapur', 1, NULL, '', ''),
(68, '853661', 'Jayshree Amande', '+91 93738 99921', 'Pune', 8, '6', 0, 'Active', 'Monthly', 0, 63, 6, '1990-01-01', 'Mr. Guru Joshi', 21, 'Resident', 'Female', 'corporatemis@dandekarbrothers.com', '', NULL, NULL, 'Pune', 1, 'Admin', '', ''),
(69, 'B96D1B', 'Shubham Vithal Pandhare', '9767164912', 'sangli', 11, '5', 233, 'Deactive', 'Monthly', 7000, 15, 6, '2021-06-11', 'Shahid', 21, 'Resident', 'Male', 'shubham.pandhare@spconcare.com', '', '0D3D89B1596304403500.jpg', NULL, 'Sangli', 3, NULL, '', ''),
(70, '1E2530', 'Sebastian Juje Fernandes', '9175915084', 'B/104, Odyssey D.H.S.Lodha Paradise,\r\nEasterm Express Highway Majiwade, Thane West Kasarvadavali Thane.', 6, '1', 6666, 'Active', 'Monthly', 200000, 15, 6, '1975-08-29', 'Mumbai', 21, 'Resident', 'Male', '', 'AALPF5385N', NULL, NULL, '9011744411', 1, 'Admin', '', ''),
(71, 'FC2478', 'Ashwini Akshay Sawant', '7620247718', 'At- Radewadi, Post- Ankalkhop, Tal- Palus, Dist- sangli', 32, '12', 235, 'Active', 'Monthly', 7000, 316, 6, '1999-12-16', 'Radewadi', 21, 'Resident', 'Female', 'ashwini33sawant@gmail.com', '0DAGPG5916Q', NULL, NULL, '9561921967', 1, NULL, '', ''),
(72, '9C4605', 'Sudhir Babasaheb Mhetre', '9766314745', 'Dindi Ves, Malgaon Road, Samarth Colony, Miraj', 36, '15', 357, 'Active', 'Monthly', 10000, 63, 6, '1991-12-13', 'Miraj', 21, 'Resident', 'Male', 'mhetresudhir20@gmail.com', 'DCEPM0021A', NULL, NULL, '9119475715', 1, NULL, '', ''),
(74, '3FB276', 'Shreekant Ashokrao Kakade', '09673185232', 'S/O Ashokrao Kakade, House No 852, Shivaji Nagar Area Talni, \r\nAtPost. Talni, TQ Hadgaon , Talni, Nanded, TQ Hadgaon, Nanded, 431743', 38, '15', 3577, 'Active', 'Monthly', 93000, 63, 6, '1989-12-06', 'Pune', 21, 'Resident', 'Male', 'kakade89@yahoo.com', 'BJNPK9609N', NULL, NULL, 'Pune', 1, NULL, '', ''),
(76, 'E306D0', 'Ganesh Vishwanath Dalvi', '9175917743', 'Regency Sarvam, Tower No. 06, Flat No. 1102,\r\n11th Floor,Ganesh Mandir Road, Titwala ( East) -421605\r\nTaluka - Kalyan, Dis -Thane, State Maharashtra.', 6, '1', 16000, 'Deactive', 'Monthly', 54533, 63, 6, '1976-01-20', '9011744411', 21, 'Resident', 'Male', 'ganesh.dalvi@spconcare.com', 'AJIPD2197C', NULL, NULL, 'Mumbai', 1, NULL, '', ''),
(77, '6F8EB2', 'Shashira Anna Kambale', '9175107250', 'Road No-6, Near Kumbhar Engineering Samtanagar Miraj, 416410', 11, '5', 554, 'Deactive', 'Monthly', 15500, 63, 6, '1981-02-14', '  Sangli', 21, 'Resident', 'Male', 'plant.m@spconcare.com', 'BTUPK4545A', NULL, NULL, ' 0', 3, NULL, '', ''),
(79, 'F5AE43', 'Vishal Sanjay Desai', '8149969800, 9156346700', 'Siddheshwar Colny , Behind MSCB Bord, Tasgaon', 37, '15', 400, 'Active', 'Monthly', 12000, 63, 6, '1996-07-11', '9011744411', 21, 'Resident', 'Male', 'vishal.desai@spconcare.com', 'GDEPD8702B', NULL, NULL, 'Tasgaon', 1, NULL, '', ''),
(82, '01F7AF', 'Amod Sathe', '9967436812', 'Flat No 2, Guru Darashan C.H.S, Manpada Road, Opposite Kasturi Plaza, Dombivli East, Kalyan, Thane, Tilaknagar, Maharashtra 421201', 6, '1', 1250, 'Deactive', 'Monthly', 35000, 15, 6, '2022-07-05', 'Mumbai', 21, 'Resident', 'Male', '', 'CGJPS8045L', NULL, NULL, '0', 1, NULL, '', ''),
(83, 'AFDE35', 'Sanjay Ramchandra Dalavi', '9689002260', 'Flat No.1, Vashista Enclve Appt. &quot;Near Datta Mandir, Govt.Colony, Vishrambag Sangli.', 33, '12', 962, 'Active', 'Monthly', 25000, 15, 6, '1972-07-25', '  Sangli', 21, 'Resident', 'Male', 'hr@spconcare.com', 'AINPD5367N', NULL, NULL, '9011744411', 1, NULL, '', ''),
(84, '611975', 'Javed Sikandar Jamadar', '8459757438', 'Nadives Shastri Chowk, Jawahar college road, near fatima masjid. Mandle mala Miraj', 18, '5', 450, 'Active', 'Monthly', 11700, 15, 6, '1996-03-15', '0', 21, 'Resident', 'Male', 'jamadarjs08@gmail.com', 'BUZPJ8408B', NULL, NULL, 'Sangli', 1, NULL, '', ''),
(85, '326104', 'Swapnil Machindra Salunkhe', '7798090132', 'Khanapur Road, Hanmant Nagar, Vita, Sangli, Maharashtra, 415311', 13, '5', 692, 'Active', 'Monthly', 18000, 15, 6, '1993-06-10', '0', 21, 'Resident', 'Male', 'swapnilsalunkhe2025@gmail.com', 'JBEPS6509C', NULL, NULL, 'sangli', 1, NULL, '', ''),
(86, 'AB02C6', 'Vedant Sandeep Sawant', '8956116533', '102&amp;103, Jay Shakti Complex, Plot no. 68, Phase 2, Navade, Panvel, Maharashtra. 410208.', 19, '1', 846, 'Active', 'Monthly', 22000, 15, 6, '1999-08-07', '0', 21, 'Resident', 'Male', 'vedant.sawant@spconcare.com', 'JGRPS4030J', NULL, NULL, 'Mumbai', 1, NULL, '', ''),
(87, '91C0DF', 'Pranali Vinayak Patil', '8956116534', 'At Shree Ganesh Krupa nieas Deo ali, Pen, Post-Pen, Tal-Pen, Dist Raigad, Maharashtra 402107.', 19, '1', 769, 'Active', 'Monthly', 20000, 15, 6, '2001-02-11', '0', 21, 'Resident', 'Female', 'pranali.patil@spconcare.com', 'GXUPP2177J', NULL, NULL, 'Mumbai', 1, NULL, '', ''),
(88, '103DFA', 'Sakshi Sudhir Gudhekar', '8956116535', 'Aditya Mangalya So, At Post - Pen, Dist- Raigad, Maharashtra, 402107.', 19, '1', 846, 'Deactive', 'Monthly', 22000, 15, 6, '2001-02-14', '0', 21, 'Resident', 'Female', 'sakshi.gudhekar@spconcare.com', 'DAGPG7716A', NULL, NULL, 'Mumbai', 1, NULL, '', ''),
(89, 'C5B2F1', 'Sneha Satish Musale', '8956116536', 'At/post- Khamb, Tal-Roha,Dist-Raigad, Maharashtra 402304.', 19, '1', 846, 'Active', 'Monthly', 22000, 15, 6, '1998-05-13', '0', 21, 'Resident', 'Female', 'sneha.musale@spconcare.com', 'FFXPM5514L', NULL, NULL, 'Mumbai', 1, NULL, '', ''),
(90, 'D7333C', 'Vaibhav Janardan Agaj', '8956116537', 'Tembhari Chowk, Manivali Raigarh, Maharashtra 410206.', 19, '1', 769, 'Deactive', 'Monthly', 20000, 15, 6, '2001-07-18', '0', 21, 'Resident', 'Male', 'vaibhav.agaj@spconcare.com', 'DPDPA1327H', NULL, NULL, 'Mumbai', 1, NULL, '', ''),
(91, 'E8653E', 'Manish Pradip Shelke', '8956116538', 'Balai Road, Kasam Bhat,Uran, Raigarh, Maharashtra, 400702.', 19, '1', 769, 'Deactive', 'Monthly', 20000, 15, 6, '2000-10-30', '0', 21, 'Resident', 'Male', 'manish.shelke@spconcare.com', 'KHCPS5011Q', NULL, NULL, 'Mumbai', 1, NULL, '', ''),
(92, '4B18DB', 'Dhiraj Hindurao Pednekar', '9503337300', 'A/19, Rupchand Apartment, Near Ashapura Mandir, Opp. Kapur Bawadi Police Station, Kapur Bawadi, Thane (W) 400602', 20, '9', 2115, 'Deactive', 'Monthly', 55000, 15, 6, '1983-11-18', 'Sangli', 21, 'Resident', 'Male', 'dhirajpednekar83@gmail.com', 'ALUPP3167E', NULL, NULL, '0', 3, NULL, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `helpd_comment`
--

CREATE TABLE `helpd_comment` (
  `comment_id` int(11) NOT NULL,
  `quiry_id` int(11) NOT NULL,
  `ticket_id` varchar(200) NOT NULL,
  `idemployeemaster` int(11) NOT NULL,
  `ticket_reply` text NOT NULL,
  `date_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `helpd_ticket`
--

CREATE TABLE `helpd_ticket` (
  `quiry_id` int(11) NOT NULL,
  `iddepartment` int(11) NOT NULL,
  `idemployeemaster` int(11) NOT NULL,
  `qry_title` text NOT NULL,
  `qry_description` text NOT NULL,
  `ticket_id` varchar(20) NOT NULL,
  `status` int(20) NOT NULL,
  `priority_id` int(11) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order_appointment`
--

CREATE TABLE `order_appointment` (
  `appointment_id` int(11) NOT NULL,
  `appointment_date` date NOT NULL,
  `appointment_detail` text NOT NULL,
  `appointment_time` text DEFAULT NULL,
  `appointment_address` text NOT NULL,
  `appointment_doc` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remark` text NOT NULL,
  `app_status` text NOT NULL,
  `ord_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_appointment`
--

INSERT INTO `order_appointment` (`appointment_id`, `appointment_date`, `appointment_detail`, `appointment_time`, `appointment_address`, `appointment_doc`, `remark`, `app_status`, `ord_id`) VALUES
(137, '2023-10-11', 'asa', '15:56', 'ssxs', '[\"uploads/652a6cc8b97ad_HSC Result March-2022.pdf\"]', 'xsxsx', 'Pending', 4);

-- --------------------------------------------------------

--
-- Table structure for table `ord_inquiry`
--

CREATE TABLE `ord_inquiry` (
  `ord_id` int(11) NOT NULL,
  `cust_id` int(11) NOT NULL,
  `item_cat` int(11) NOT NULL,
  `item_name` int(11) NOT NULL,
  `inq_tit` text NOT NULL,
  `inq_desc` text NOT NULL,
  `datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ord_inquiry`
--

INSERT INTO `ord_inquiry` (`ord_id`, `cust_id`, `item_cat`, `item_name`, `inq_tit`, `inq_desc`, `datetime`) VALUES
(1, 1, 41, 57, 'requirment', 'we need 100 kg powder filler', '2023-09-30 16:05:00'),
(2, 2, 2, 1, 'pen dispacked', 'poen', '2023-10-03 12:05:39'),
(3, 3, 3, 3, 'NoteBook', 'Purchased', '2023-10-03 12:53:27'),
(4, 4, 34, 12, 'Order by Purched pens stock', 'Null', '2023-10-07 19:27:24');

-- --------------------------------------------------------

--
-- Table structure for table `priority_master`
--

CREATE TABLE `priority_master` (
  `priority_id` int(11) NOT NULL,
  `priority_name` text NOT NULL,
  `priority_desci` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `priority_master`
--

INSERT INTO `priority_master` (`priority_id`, `priority_name`, `priority_desci`) VALUES
(8, 'dfvdbrgergrgr', 'bdbdfvfdervrfvrvbrtbtrb');

-- --------------------------------------------------------

--
-- Table structure for table `prod_category`
--

CREATE TABLE `prod_category` (
  `idcat` int(11) NOT NULL,
  `category_name` text DEFAULT NULL,
  `cate_shortname` text DEFAULT NULL,
  `comp_id` varchar(250) DEFAULT NULL,
  `parent_category` varchar(250) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `status` text DEFAULT NULL,
  `category_for` varchar(200) DEFAULT NULL,
  `sellgoodscat` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `prod_category`
--

INSERT INTO `prod_category` (`idcat`, `category_name`, `cate_shortname`, `comp_id`, `parent_category`, `description`, `status`, `category_for`, `sellgoodscat`) VALUES
(35, 'Packing Material', 'PM', '6', '-Select Parent Category-', '', NULL, 'Stockitem', ''),
(36, 'Barrel', 'BR', '6', '35', '', NULL, 'Stockitem', ''),
(37, 'Can', 'CN', '6', '35', '', NULL, 'Stockitem', ''),
(38, 'Bag', 'BG', '6', '35', '', NULL, 'Stockitem', ''),
(39, 'Box', 'BX', '6', '35', '', NULL, 'Stockitem', ''),
(40, 'Finished Goods', 'FG', '6', '-Select Parent Category-', '', NULL, 'Stockitem', '1'),
(41, 'Admixture', 'AM', '6', '40', '', NULL, 'Stockitem', ''),
(42, 'Waterproofing', 'WP', '6', '40', '', NULL, 'Stockitem', ''),
(43, 'Repair &amp; Strengthening', 'RS', '6', '40', '', NULL, 'Stockitem', ''),
(44, 'Flooring', 'FLR', '6', '40', '', NULL, 'Stockitem', ''),
(45, 'Protective Coating', 'PC', '6', '40', '', NULL, 'Stockitem', ''),
(46, 'Joint Sealant', 'JS', '6', '40', '', NULL, 'Stockitem', ''),
(47, 'Raw  Material', 'RM', '6', '-Select Parent Category-', '', NULL, 'Stockitem', ''),
(48, 'Resin', 'RE', '6', '47', '', NULL, 'Stockitem', ''),
(49, 'Hardner', 'HD', '6', '47', '', NULL, 'Stockitem', ''),
(50, 'Liquid Additive', 'LQA', '6', '47', '', NULL, 'Stockitem', ''),
(51, 'Powder Additive', 'PWA', '6', '47', '', NULL, 'Stockitem', ''),
(52, 'Powder Filler', 'PWF', '6', '47', '', NULL, 'Stockitem', ''),
(53, 'Polymers', 'PMR', '6', '47', '', NULL, 'Stockitem', ''),
(54, 'Pigments', 'PGM', '6', '47', '', NULL, 'Stockitem', ''),
(55, 'Sand', 'SND', '6', '47', '', NULL, 'Stockitem', ''),
(56, 'Miscellaneous Packing', 'MISC', '6', '35', '', NULL, 'Stockitem', ''),
(57, 'Trading Goods', 'TR', '6', '40', '', NULL, 'Stockitem', ''),
(58, 'Adhesive', 'ADH', '6', '40', '', NULL, 'Stockitem', ''),
(59, 'Grouting', 'GR', '6', '40', '', NULL, 'Stockitem', ''),
(60, 'Solvents', 'SLV', '6', '47', '', NULL, 'Stockitem', ''),
(61, 'Application', 'Application', '6', '-Select Parent Category-', 'Product Application and service', NULL, 'Service', NULL),
(62, 'Phenalkamine hardener', 'Phenalkamine hardener', '6', '49', 'Phenalkamine hardener', NULL, 'Stockitem', NULL),
(63, 'Adhesive R', 'Adhesive R', '6', '47', 'Adhesive R', NULL, 'Stockitem', NULL),
(64, 'Repair &amp; Strengthening R', 'Repair &amp; Strengthening R', '6', '43', 'Repair &amp; Strengthening', NULL, 'Stockitem', NULL),
(65, 'Repair &amp; Strengthening (R)', 'Repair &amp; Strengthening (R)', '6', '47', 'Repair &amp; Strengthening (R)', NULL, 'Stockitem', NULL),
(66, 'Silica', 'Silica', '6', '40', 'DR Silica Products', NULL, 'Stockitem', NULL),
(67, 'AMB -642', 'AMB -642', '6', '36', 'AMB -642', NULL, 'Stockitem', NULL),
(68, 'AMB 642', 'AMB -642', '6', '39', 'AMB', NULL, 'Stockitem', NULL),
(69, 'Semi Finished Goods', 'SFG', '6', '40', 'Semi Finished Goods', NULL, 'Stockitem', NULL),
(70, 'Powder Additive', 'Powder Additive', '7', '47', '', NULL, 'Stockitem', NULL),
(71, 'Audit', 'Audit', '6', '-Select Parent Category-', 'Service Audit', NULL, 'Service', NULL),
(72, 'Powder Filler', 'Powder Filler', '7', '47', 'Powder Filler', NULL, 'Stockitem', NULL),
(73, 'Bag', 'Bag', '7', '35', 'Bag', NULL, 'Stockitem', NULL),
(74, 'Packing Material', 'Packing Material', '7', '35', 'Packing Material', NULL, 'Stockitem', NULL),
(75, 'Transportation', 'Transportation', '6', '-Select Parent Category-', 'Local and other transportation service', NULL, 'Service', NULL),
(76, 'Factory tools', 'factory tools', '6', '35', 'factory tools', NULL, 'Stockitem', NULL),
(77, 'Finished Goods', 'Finished Goods', '7', '40', 'Finished Goods', NULL, 'Stockitem', NULL),
(78, 'Grouting', 'Grouting', '7', '40', '', NULL, 'Stockitem', NULL),
(79, 'Sand', 'Sand', '7', '47', '', NULL, 'Stockitem', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `query_master`
--

CREATE TABLE `query_master` (
  `query_id` int(11) NOT NULL,
  `query_name` text DEFAULT NULL,
  `query_desc` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `query_master`
--

INSERT INTO `query_master` (`query_id`, `query_name`, `query_desc`) VALUES
(7, 'cee', 'cde');

-- --------------------------------------------------------

--
-- Table structure for table `state_master`
--

CREATE TABLE `state_master` (
  `state_id` int(11) NOT NULL,
  `state_name` text NOT NULL,
  `state_abbrivation` text NOT NULL,
  `state_ut` int(11) NOT NULL,
  `status` varchar(200) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `state_master`
--

INSERT INTO `state_master` (`state_id`, `state_name`, `state_abbrivation`, `state_ut`, `status`, `country_id`) VALUES
(1, 'Andaman and Nicobar', 'AN', 35, NULL, 95),
(2, 'Andhra Pradesh', 'AP', 28, NULL, 95),
(3, 'Arunachal Pradesh', 'AR', 12, NULL, 95),
(4, 'Assam', 'AS', 18, NULL, 95),
(5, 'Bihar', 'BH', 10, NULL, 95),
(6, 'Chandigarh', 'CH', 4, NULL, 95),
(7, 'Chhattisgarh', 'CH', 22, NULL, 95),
(8, 'Dadra and Nagar Haveli', 'DN', 26, NULL, 95),
(9, 'Daman and Diu', 'DD', 25, NULL, 95),
(10, 'Delhi', 'DL', 7, NULL, 95),
(11, 'Goa', 'GA', 30, NULL, 95),
(12, 'Gujarat', 'GJ', 24, NULL, 95),
(13, 'Haryana', 'HR', 6, NULL, 95),
(14, 'Himachal Pradesh', 'HP', 2, NULL, 95),
(15, 'Jammu and Kashmir', 'JK', 1, NULL, 95),
(16, 'Jharkhand', 'JH', 20, NULL, 95),
(17, 'Karnataka', 'KA', 29, NULL, 95),
(18, 'Kerala', 'KL', 32, NULL, 95),
(19, 'Lakshadweep', 'LD', 31, NULL, 95),
(20, 'Madhya Pradesh', 'MP', 23, NULL, 95),
(21, 'Maharashtra', 'MH', 27, NULL, 95),
(22, 'Manipur', 'MN', 14, NULL, 95),
(23, 'Meghalaya', 'ME', 17, NULL, 95),
(24, 'Mizoram', 'MI', 15, NULL, 95),
(25, 'Nagaland', 'NL', 13, NULL, 95),
(26, 'Odisha', 'OR', 21, NULL, 95),
(27, 'Puducherry', 'PY', 34, NULL, 95),
(28, 'Punjab', 'PB', 3, NULL, 95),
(29, 'Rajasthan', 'RJ', 8, NULL, 95),
(30, 'Sikkim', 'SK', 11, NULL, 95),
(31, 'Tamil Nadu', 'TN', 33, NULL, 95),
(32, 'Telangana', 'TS', 36, NULL, 95),
(33, 'Tripura', 'TR', 16, NULL, 95),
(34, 'Uttar Pradesh', 'UP', 9, NULL, 95),
(35, 'Uttarakhand', 'UT', 5, NULL, 95),
(36, 'West Bengal', 'WB', 19, NULL, 95),
(37, 'Andhra Pradesh (New)', 'AD', 37, NULL, 95),
(38, 'Non Indian Country', 'NIC', 38, NULL, 95);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `acadamicyear`
--
ALTER TABLE `acadamicyear`
  ADD PRIMARY KEY (`idacadamicyear`),
  ADD UNIQUE KEY `yearname_UNIQUE` (`yearname`),
  ADD UNIQUE KEY `year_abbr` (`year_abbr`);

--
-- Indexes for table `companymaster`
--
ALTER TABLE `companymaster`
  ADD PRIMARY KEY (`comp_id`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`iddepartment`);

--
-- Indexes for table `employeemaster`
--
ALTER TABLE `employeemaster`
  ADD PRIMARY KEY (`idemployeemaster`),
  ADD KEY `fk_employeemaster_post1` (`postnm`);

--
-- Indexes for table `helpd_comment`
--
ALTER TABLE `helpd_comment`
  ADD PRIMARY KEY (`comment_id`);

--
-- Indexes for table `helpd_ticket`
--
ALTER TABLE `helpd_ticket`
  ADD PRIMARY KEY (`quiry_id`),
  ADD UNIQUE KEY `ticket_id` (`ticket_id`);

--
-- Indexes for table `order_appointment`
--
ALTER TABLE `order_appointment`
  ADD PRIMARY KEY (`appointment_id`);

--
-- Indexes for table `ord_inquiry`
--
ALTER TABLE `ord_inquiry`
  ADD PRIMARY KEY (`ord_id`);

--
-- Indexes for table `priority_master`
--
ALTER TABLE `priority_master`
  ADD PRIMARY KEY (`priority_id`);

--
-- Indexes for table `prod_category`
--
ALTER TABLE `prod_category`
  ADD PRIMARY KEY (`idcat`);

--
-- Indexes for table `query_master`
--
ALTER TABLE `query_master`
  ADD PRIMARY KEY (`query_id`);

--
-- Indexes for table `state_master`
--
ALTER TABLE `state_master`
  ADD PRIMARY KEY (`state_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `acadamicyear`
--
ALTER TABLE `acadamicyear`
  MODIFY `idacadamicyear` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `companymaster`
--
ALTER TABLE `companymaster`
  MODIFY `comp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `iddepartment` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `employeemaster`
--
ALTER TABLE `employeemaster`
  MODIFY `idemployeemaster` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=134;

--
-- AUTO_INCREMENT for table `helpd_comment`
--
ALTER TABLE `helpd_comment`
  MODIFY `comment_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order_appointment`
--
ALTER TABLE `order_appointment`
  MODIFY `appointment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=138;

--
-- AUTO_INCREMENT for table `ord_inquiry`
--
ALTER TABLE `ord_inquiry`
  MODIFY `ord_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `priority_master`
--
ALTER TABLE `priority_master`
  MODIFY `priority_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `prod_category`
--
ALTER TABLE `prod_category`
  MODIFY `idcat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;

--
-- AUTO_INCREMENT for table `query_master`
--
ALTER TABLE `query_master`
  MODIFY `query_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `state_master`
--
ALTER TABLE `state_master`
  MODIFY `state_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
